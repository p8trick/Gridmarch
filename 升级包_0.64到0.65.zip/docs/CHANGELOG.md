# 更新记录（每次交付改了哪些文件）

> 用途：你跳过了某几个版本时，告诉我你现在的版本，我用 `docs/manifests/` 里的快照一键生成升级包；也可以自己把「你现在的版本之后」每一版的文件取并集。
> 每次交付的更新包里也有 `更新说明.md`，写的是相对上一版的改动；累计包会注明"从 vN 升级"。
> 更新后别忘了把 `index.html` 里的 `GM_VERSION` 加一位（避开手机旧缓存）。

## 0.65

- **加载画面的跑步步兵**：进度条上方有一个蓝军步兵，脚踩在进度条上沿，站在填充端上跟着进度前进（进入战斗 / 换图都有）。步兵和跑步循环就是游戏里原有的模型和动作（`soldier-rig.js` 的 `sampleCycle('run')`），用 `tools/make-runner-frames.py` 把一个循环等分成 12 帧拍成透明底 WebP（`assets/loading/runner-00…11.webp`，共约 80KB，侧面正交相机、面朝右、脚底对齐）；改了步兵美术就重跑一遍
  - 不用实时 3D：加载画面出现时 three.js 和步兵模块还没下载好，而且生成战场那 2–3 秒主线程被卡住，实时动画会定格
  - 12 张图叠放，用 CSS opacity 关键帧逐帧切换（0.72 秒一个循环）；位置用和进度条填充同一个 translateX 缓动。opacity / transform 动画走合成器线程，主线程卡住时也能继续动（iOS Safari 需要真机确认，最坏情况是定格在某一帧，进度条照常走）
  - `home.js` 在主页稳定后（1.5 秒）预载这 12 帧；`prefers-reduced-motion` 下只显示第一帧
- `src/battle/loading.js`、`battle.css`、`home.js`、`tools/smoke-loading.py`（加：12 帧都加载成功）
- `index.html`：`GM_VERSION` `0.64` → `0.65`

## 0.64

- **展示窗取景自动适配**：高个子模型（步兵、反坦克兵、森林里的树）头顶被窗口上沿遮住 → `showcase.js` 现在按模型包围盒定相机的注视点和距离：注视点放到模型上下范围的中间，距离至少是基准距离，模型上下范围（加边距）和转到任意角度时的水平半径都要装进视野。矮模型保持原来的基准距离，各地块大小不会忽大忽小
- `src/battle/showcase.js`
- `index.html`：`GM_VERSION` `0.63` → `0.64`

## 0.63

- **地形小窗的地块改薄**：0.62 的地块厚度和棋盘一样（1.6），小窗里像蛋糕（放建筑时更怪）→ 改成约 0.55（边长的 1/4），像切下来的沙盘薄片；陆地分层按比例压薄、起伏减小，海的深海切面纵向压到同样厚度（`createSeaRegion` 的 bottom 参数改不动，固定 y∈[-1.6,-0.3]，所以用缩放压）。镜头也相应拉近
- **加载进度条**（进入战斗 / 换图都有）：新增 `src/battle/loading.js`。奶油色细边的圆角进度条 + 标题 + 阶段文字（「正在载入…」→「正在生成战场…」），取代原来的纯文字
  - 进度由两部分组成：**真实进度**——第一次进入战场时，home.js 把战场用到的模块文件逐个预载，按已下载个数推进前 40%；**估计进度**——生成战场是一大段同步计算（中途没法更新页面），这段按「上次实际耗时」缓动到约 92%，完成后补满、淡出。上次耗时记在 localStorage（`gm.buildMs`），越用越准
  - 进度条的填充用 transform 做 CSS transition（走合成器线程），所以主线程被生成战场卡住的时候它仍然在动
  - 换图（`mountBattle` 原地重建）没有下载阶段：进度条从 0 开始只走生成这一段
  - 进度条本身出问题时不影响进入战场（`mountBattle` 自己建一个）
- 新增 `tools/smoke-loading.py`（从主页点开始：进度条出现、进度不倒退、最后消失；换图再来一遍）
- `home.js`、`main.js`、`battle.css`、`tile-block.js`、`showcase.js`
- `index.html`：`GM_VERSION` `0.62` → `0.63`

## 0.62

- **详细面板的小窗改成纯模型展示**（不再是战场快照）：每个小窗是独立的小「摄影棚」场景（暖米色背景 + 三点布光 + 软落影，同兵工厂转台），固定 3/4 角度，手指拖动转模型（左右转 / 上下改俯仰）。同一个 renderer，viewport + scissor 画进窗口矩形；只在刚打开 / 拖动后画几帧
  - 单位盒：高精度模型（和兵工厂同一份缓存，抽到新文件 `unit-models.js`，`arsenal.js` 改用它）。**目前只有 6 个兵种有模型**（步兵 / 反坦克兵 / 轻坦 / 中坦 / 重坦 / 自行火炮），其余 5 个（侦察车 / 运输车 / 火箭炮 / 防空炮 / 防空导弹）小窗显示「尚未建模」
  - 地形盒：带厚度的方块地块（`tile-block.js`）：2×2、顶面 y=0、底面 y=BASE_Y（和棋盘 / 深海切面同深度）、**没有底座**。侧面：陆地类用地层截面（草缘 / 土 / 砾石 / 土 / 岩，配色和分层沿用 world.js 沙盘侧壁），海用你做的深海切面（createBoardCutaway，单格四面）。顶面和摆件复用现有美术：树 / 山 / 建筑（带军队色）/ 沙漠 / 沼泽 / 路 / 桥 / 岩石；河、浅滩、断崖是用顶面颜色 + 小摆件拼的（临时）。每种地块以后有了自己的侧面美术，只改 `tile-block.js` 里的 `SIDE` 表
- **去掉棋盘底座**（`world.js`）：原来棋盘四周有一圈比棋盘大的底座（外扩 0.2 的台阶 + 深色裙边），现在删掉，地层侧壁 / 深海切面直接落到 BASE_Y，像沙盘切出来的一块；棋盘下面垫一层很淡的软阴影，深色背景上不至于悬空
- **关闭方式**：去掉右上角关闭按钮，点盒子外面的暗处关闭（盒子里的空白处不关）；底部小字改成「点一项看说明 · 拖动小窗转模型 · 点空白处关闭」
- **可点项目改成小按键**：微微凸起（下面一道深色细边），按下去陷进去，选中仍是橙色描边
- 新增 `src/battle/unit-models.js` / `tile-block.js` / `showcase.js`；`detail.js`、`arsenal.js`、`main.js`、`battle.css`、`world.js`；`tools/smoke-detail.py` 同步
- `index.html`：`GM_VERSION` `0.61` → `0.62`

## 0.61

- **详细面板加展示窗**：每个盒子左上一个小窗，不开新画布、不用新模型——用战场同一个 renderer 和场景换近景相机，在窗口矩形里（viewport + scissor）再画一遍。单位盒 = 单位近景，地形盒 = 地形俯视带周围；手指在小窗上拖动转视角。窗口是透明洞（同兵工厂 .ars-pv：外扩阴影铺奶油底，压暗层挖洞）。阴影图沿用战场刚画的那张；只在刚打开 / 拖动后画几帧，静止不出帧；面板开着时光圈先藏起来（它的 30 帧动画会让战场持续重画），关闭后恢复
- **点一项看说明**：血量 / 状态 / 机动 / 视野 / 射程 / 移动 / 燃料 / 弹药 / 主炮 / 副炮 / 能打的大类 / 防御星 / 四种移动消耗 / 收入 / 占领点数 / 归属 / 沼泽掉血，点一下高亮 + 底部说明栏（固定三行高，盒子高度不跳）换成解释，再点取消；默认显示单位一句话定位 / 这一格对格上单位的实际减伤。说明按真实规则写：燃料关闭、没有战争迷雾、占领未实装都会如实说
- 关闭：点盒子外面的暗处，或右上角「关闭」按钮；盒子里的空白处不关闭
- 新增 `src/battle/explain.js`（全部说明文字 + 纯函数，数字从规则数据算）；`detail.js` 重写；`unit-info.js` 的主副炮块加 `data-k`（兵工厂无影响）；`main.js` 接入主循环；`battle.css`；`tools/smoke-detail.py` 扩充（展示窗像素 / 点选 / 拖动 / 关闭按钮 / 压力测试改为按兵种分块并打日志）
- `index.html`：`GM_VERSION` `0.60` → `0.61`

## 0.60

- **长按格子看完整参数（详细面板）**：单击仍只出简要面板；长按约 0.45 秒（手指没动）出「玩具盒」风格详细面板（同兵工厂：奶油底 + 深色粗边 + 军队色条）。格上有单位 = 左「单位盒」+ 右「地形盒」两个独立盒子；没有单位 = 只有地形盒。点任意位置关闭
  - 单位盒：名字 / 军队 / 可行动或已行动、血量条、机动、视野、射程、移动类型、燃料、弹药（当前/满值）、主炮 / 副炮能打的大类（和兵工厂同一套）、间接火力 / 可占领提示
  - 地形盒：名字、一句话说明、防御星（4 格）+ 对格上单位的实际减伤（星数 × 当前血量格数 %）、步兵 / 反坦克兵 / 履带 / 轮式四种移动消耗（不能进 = ✕，格上单位的那一列高亮）、建筑收入 / 占领点数 / 归属、沼泽掉血提示。数据全部来自规则引擎
  - 长按己方兵工厂 = 看详情（点按仍是生产界面）；长按触发后手指继续移动不会拖动战场，抬手也不会再算一次点按
- 新增 `src/battle/detail.js`、`src/battle/unit-info.js`（主副炮块 / 单位符号抽出来，兵工厂和详细面板共用）；`arsenal.js` 改用它（外观不变）；`main.js`、`battle.css`；`tools/smoke-detail.py`（长按冒烟 + 11 兵种 × 17 地形共 374 个盒子防截断压力测试）
- **瘦身**：`assets/_src/`（PNG 母版 7MB）和 `assets/splash/`（iPad 启动图 4.7MB）移出仓库，打成 `素材备份_src与splash.zip` 放在 `.github/workflows/`（机器人不碰那个目录）；`index.html` 里启动图 link 改成注释（iPad 开机会白屏一瞬）。恢复方法写在 `docs/HOME.md` 和 index.html 注释里
- `index.html`：`GM_VERSION` `0.59` → `0.60`

## 0.59

- **修：换回合横幅里「蓝色条纹跳动」**。推测原因（无头浏览器里复现不出，需真机确认）：① 扫光条用 `left` 做动画，`left` 会触发重排，iOS 上一格一格跳，而且半透明白条盖在深蓝底上看起来偏蓝；② 斜切、边框、内阴影和扫光全挂在同一个被动画的元素上，每帧重绘；③ 金字用了 `background-clip:text` + `filter`，WebKit 上带动画容易闪。现在：动画只动最外层的 `transform`（`will-change`）；斜切带本体（`.bs`）静止不动；扫光改成 `transform` 平移、颜色改成偏暖的金白；阵营色底边改成单独一条（不再用 border）；金字改成纯色 + 描边阴影，去掉 `background-clip` / `filter`
- `src/battle/main.js`、`src/battle/battle.css`；`index.html`：`GM_VERSION` `0.58` → `0.59`
- **窗口结束（0.50–0.59）**：`docs/HANDOFF.md` 按本窗口更新（兵工厂 / 战场界面 / 结束回合 / 教训 16–21）；`docs/manifests/` 只保留最近 10 个快照（0.49、0.51–0.59），其余删除；交付完整包 `Gridmarch_v0_59.zip`

## 0.58

- **结束回合**：点左上状态条 → 状态条正下方弹出确认条（小箭头指回状态条）：「结束第 N 天 · 回合方 的回合？」，有兵工厂没生产时多一行金色提示「还有 N 座兵工厂没生产」；按钮「取消」/「结束回合」（金色）；点外面 = 取消。确定后走引擎 `endTurn`：换人、天数（回到蓝军才 +1）、单位恢复行动、新一方领收入、兵工厂可再生产。单位没行动这一项的提示，等移动 / 攻击接入后再加
- **让新手知道能点**：状态条右端加了一个小金标（▶）；本方单位**全部行动完**的那一刻自动弹出同一个确认条；取消之后状态条继续金光脉冲、小金标跳动，直到结束回合
- **换回合大横幅**：中央一条主页同款斜切深蓝带（金边、阵营色底边）从左滑入，金色粗体「第 N 天」缩放落下，一道扫光，右侧「● 蓝军 / 红军行动」，停一下向右滑出（约 1.7 秒，期间挡住触摸）
- 已知限制：沼泽掉血致死的单位，引擎里会删除但战场里的模型暂不移除（单位死亡表现等战斗接入时一起做；当前没有单位能移动到沼泽上，不会触发）
- 新增 `tools/smoke-endturn.py`（结束回合冒烟测试）；`src/battle/main.js`、`src/battle/battle.css`；`index.html`：`GM_VERSION` `0.57` → `0.58`

## 0.57

- **旋转按钮图标放大**：字符 ⟳ 比 ☰ 小，改成 SVG 顺时针圆箭头（25px），和菜单图标视觉相当；视距数字仍临时替换它
- **视距加第四档 11 格**：`CAMERA.ZOOMS` = 5 / 7 / 9 / 11（自由缩放范围本来就到 11，只是松手会吸回 9）；阴影半径 27 → 33，视距 11 时阴影仍覆盖整个画面
- **详细信息面板**：点格子（棋盘内）后，面板出现在**光圈所在位置的另一侧**（光圈在左半屏 → 右下，反之左下；屏幕中间 46%–54% 不切换，免得抖；相机拖动 / 旋转后跟着换边）。上面是**单位卡**（军队色点 + 名字、血量条 N/10、燃料、弹药；格上没有单位就不出现），下面是**地形卡**（地形名、防御星、建筑显示归属蓝军 / 红军 / 中立）。数据全部来自引擎；点棋盘外收起；生产后面板同步刷新
- 边距沿用 `--pad-l`；面板不拦截触摸（点穿到战场）
- `src/battle/main.js`、`src/battle/camera.js`、`src/battle/battle.css`；`index.html`：`GM_VERSION` `0.56` → `0.57`

## 0.56

- **左上状态条和右上两个按钮缩小**：高度 44 → 36，字号 / 图标 / 间距同步缩小（边距规则不变）
- **视距提示**：缩放（双指 / 滚轮 / 松手吸附）时，右上「旋转」按钮临时变成当前视距数字（格数，随缩放实时变化，松手吸附后显示 5 / 7 / 9）；停手 2 秒后淡出变回旋转图标（双指还按着就继续等）；显示数字时点一下 = 立刻变回图标并旋转。暂停菜单里的「视距」按钮删除
- **修复：暂停菜单「换边」没反应**：0.55 里菜单委托和旧的 `bSide.onclick` 各切一次，一次点击切了两次等于没变；删掉旧的 onclick
- `src/battle/main.js`、`src/battle/battle.css`；`index.html`：`GM_VERSION` `0.55` → `0.56`

## 0.55

- **战场界面重做**：去掉左上「主页 / 换边」、右上「⟲ ⟳ 视距 换图」和左下说明面板。现在是：
  - **左上**：`第 N 天 | ● 回合方 | 金币图标 + 当前回合方资金`（斜切深蓝条，同主页按钮风格）
  - **右上**：两个图标按钮 = **旋转画面（顺时针 90°）** + **暂停菜单**（☰）。左右两边都离短边 `var(--pad-l)`（= `max(5sw, 56px)`，倾斜后可见边缘约 52px），和主页、兵工厂一致
  - **暂停菜单**（面板同主页设置面板，按钮直接用主页的 `.item`）：继续 / 视距 · N 格 / 换边（仅画面被旋转时出现，长按仍是现场诊断）/ 换图 / 返回主页；面板右上小字显示关卡名和种子；点面板外 = 继续
  - 点格子仍有光圈，但不再显示地形 / 单位说明文字（详细信息面板另行设计，`describe()` 保留并挂在 `window.battle.describe`）；`?debug=1` 时左下角只剩一行帧率
- **兵工厂真正生产**：点「生产」→ 引擎 `produce`（扣钱、本回合这座兵工厂不能再造、新单位本回合不能行动）→ **自动关闭整个面板** → 战场上这座兵工厂出现新单位，左上金币同步。失败（本回合已造过 / 兵工厂上有单位 / 资金不足）弹提示、面板不关
- **没有模型的兵种先不能买**（侦察车、装甲运输车、火箭炮、防空炮、防空导弹）：价格签显示「未建模」，免得造出看不见的单位；引擎规则不变（`npm test` 里的 10 种可生产不受影响）
- `world.js`：单位工厂拆成 `makeUnit`，新增 `world.addUnit(spec)`；`engine-map.js`：新增 `specOfUnit()`（开局单位和新单位共用）
- `tools/smoke-arsenal.py`：生产 → 单位数 / 资金 / 面板关闭；同一座兵工厂第二次生产被拒 + 提示
- `src/battle/main.js`、`src/battle/arsenal.js`、`src/battle/battle.css`、`src/game/world.js`、`src/game/engine-map.js`、`tools/smoke-arsenal.py`；`index.html`：`GM_VERSION` `0.54` → `0.55`

## 0.54

- **展示台去掉「蓝军 / 红军」切换按钮**：兵工厂只显示自己阵营色（由兵工厂归属决定）
- **取消 0.53 的弹窗，改成「价格签变生产按钮」**：点一张兵种卡 = 选中，并且这张卡右侧的价格签变成橙色「生产 / 价格」按钮；点这个按钮才生产（仍是演示：不扣钱、不出兵），生产后还原；再点同一张卡的其他地方 = 还原成只有价格；点别的兵种卡 = 直接换成那张卡的生产按钮。买不起显示灰色「资金不足 / 价格」，暂不可生产显示灰色「暂不可 / 生产」，点了没反应
- **排版**：左边兵种列表加宽 224 → 244，右列数据 214 → 204（展示窗只窄了几个像素）
- `tools/smoke-arsenal.py` 同步：点选 → 检查生产按钮 → 换兵种 → 再点还原 → 点生产 → 关闭
- `src/battle/arsenal.js`、`src/battle/battle.css`、`tools/smoke-arsenal.py`；`index.html`：`GM_VERSION` `0.53` → `0.54`

## 0.53

- **兵工厂：点兵种卡 → 卡片右边弹出「生产」小弹窗**（带指向卡片的小箭头），点弹窗才生产（目前仍是演示：不扣钱、不出兵）；买不起 / 暂不可时弹窗置灰。列表滑动时弹窗跟着卡片走，卡片滑出可见范围就隐藏；点展示窗或生产后收起
- **原「生产」按钮改成「关闭」**（右下角）；**展示窗右上角的圆形 ✕ 移除**
- `tools/smoke-arsenal.py` 同步：点选兵种 → 检查弹窗 → 点弹窗 → 点「关闭」，连做 3 轮
- `src/battle/arsenal.js`、`src/battle/battle.css`、`tools/smoke-arsenal.py`；`index.html`：`GM_VERSION` `0.52` → `0.53`
- 补记：0.50–0.52 当时没有走升级包流程（补丁包名字错了，机器人把它当完整包，仓库被清成只剩补丁），这一版起补回 `docs/manifests/0.51.json`、`0.52.json`（0.50 的快照无法还原，缺）和下面三条记录

## 0.52

- **兵工厂右边改成仿高战2 排版**：转台在左，右列从上到下 = 机动 / 视野 / 燃料三行 + 主炮块 + 副炮块 + 按钮。每个武器块：武器名 + 弹药（射程不是 1 的带「射程」），下面只列「能打的大类」小块（竖排「主炮 / 副炮」标签）
- `rules/data.js` 新增兵种大类 `UNIT_CAT` / `CAT_ORDER` / 阈值 `WEAPON_LIST_MIN`（某武器对某大类里最高基础伤害 ≥ 30 才列出；按高战2 轻坦截图反推：主炮对步兵 25 不列、机枪对车辆 45 列；阈值是猜的）。以后加直升机 / 飞机 / 船 / 潜艇，给新单位标上大类即可
- 武器名在 `arsenal.js` 的 `WPN` 表（我自己起的名字，可改）
- `src/battle/arsenal.js`、`src/battle/battle.css`、`src/rules/data.js`；`index.html`：`GM_VERSION` `0.51` → `0.52`

## 0.51

- 兵工厂展示盒下沿加「火力」：主炮 / 副炮各一排 11 个目标小章（目标兵种 + 基础伤害 %，强中弱三档颜色）；数据条加「燃料」（步兵、反坦克兵燃料 = `Infinity`，显示 ∞，和高战2 区分；`CONFIG.fuel` 仍关）。0.52 改成按大类，这套逐兵种小章已被替换
- `src/battle/arsenal.js`、`src/battle/battle.css`、`src/rules/data.js`；`index.html`：`GM_VERSION` `0.50` → `0.51`

## 0.50

- **兵工厂兵种列表第一下拖动发卡 → 改成自己处理滑动**：虚拟横屏（舞台旋转 90°）下，原生滚动的 `touch-action` 按物理屏幕算，浏览器要先「猜」手势；现在用 pointer 事件按 `stage.vec` 换算的纵向位移自己滑，手指一动就跟，松手带惯性，拖动时不误点卡片
- **「还能滑」标记**：上 / 下还有内容时对应一侧渐隐 + ▲ / ▼ 小箭头，滑到头自动消失；选中的卡片只有不在可见范围内才自动居中
- `src/battle/arsenal.js`、`src/battle/battle.css`；`index.html`：`GM_VERSION` `0.49` → `0.50`

## 0.49（本窗口最后一版，只改文档）

- `docs/HANDOFF.md` 按本窗口（0.40–0.49）更新：关卡适配器 `engine-map.js`、开局设定、收入改版（1000 / 小城市 700、开局资金 0）、「机械兵」改名「反坦克兵」、兵工厂界面全貌与做法（两个悬浮玩具盒、无转盘展示窗、手势、不显示视野）、风险 / 待决（语言包、真机项、动态生成单位）、路线图、新增教训 11–15（漏传升级包与 CI 红灯、`npm test` 抓不到运行时错误、容器里读中文的坑等）
- 新增 `tools/smoke-arsenal.py`：兵工厂界面无头浏览器冒烟测试（打开 → 选兵种 → 关闭 → 重开 3 轮；不在 `npm test` 里）
- `index.html`：`GM_VERSION` `0.48` → `0.49`

## 0.48

- **修复：关闭 / 重开兵工厂界面报 `ReferenceError: Can't find variable: resetView`**（红色错误条）。0.46 加双指缩放时把 `resetView` / `clampView` / `startGesture` 定义在 `build()` 里面，而 `close()` 在外面也要调 `resetView`，一关闭面板就报错。现在三者都在 `createArsenal` 外层定义。无头浏览器里补了「打开 → 选兵种 → ✕ 关闭 → 再打开」连做 3 轮的冒烟测试，无报错（`npm test` 不跑浏览器，这类运行时错误它抓不到，所以 0.46 / 0.47 没被拦住）
- `src/battle/arsenal.js`；`index.html`：`GM_VERSION` `0.47` → `0.48`

## 0.47

- **兵工厂界面左右边距一致**：两边都留 `max(5·sw, 56px)`（以灵动岛一侧为准），另一侧不再被屏幕圆角吃掉，也离手势区远一点；展示面板左右宽度相应缩小。去掉 0.46 的按灵动岛侧区分的 `side-r` 逻辑
- **去掉「视野」数值**（不做战争迷雾）：展示盒底栏只剩移动 / 射程 / 弹药三项（引擎数据里的 `vision` 保留不动）
- `src/battle/arsenal.js`、`src/battle/battle.css`；`index.html`：`GM_VERSION` `0.46` → `0.47`

## 0.46

- **兵工厂界面避开灵动岛**：灵动岛在哪边（`stage.side`），那一边就多留出 `max(5·sw, 56px)` 的空；岛在左（默认）左边留，岛在右（换边后）右边留，另一边只留 12px，所以换边后展示盒不再被遮。左盒宽度 236 → 224，展示盒相应缩小
- **展示窗手势**：单指拖动 = 转模型；**双指捏合 = 缩放 1×–4.5×**（相机拉近，能凑到模型表面看细节）；放大后**双指一起拖 = 平移观察点**；双击 = 复位；电脑上鼠标滚轮缩放；放大看细节时不自转；切换兵种自动复位。手指向量同样经 `stage.vec` 换算（虚拟横屏下横向滑动落在另一个轴上）
- `src/battle/arsenal.js`、`src/battle/battle.css`；`index.html`：`GM_VERSION` `0.45` → `0.46`

## 0.45

- **兵工厂界面改成两个悬浮的独立玩具盒**：左边「选兵种」盒（兵种单列，每张卡片：图标 / 名字 / 移动·射程 / 价格；一屏放不下就上下滑，底部渐隐提示还能滑；选中的卡片自动滚到中间；顶部资金），右边「展示」盒（整个盒子就是展示窗，模型占满；左上兵种名 + 蓝军 / 红军验收按钮，右上 ✕；下沿一条栏：移动 / 射程 / 弹药 / 视野 4 个数值 + 橙色「生产 · 价格」按钮；买不起显示灰色「资金不足 · 价格」）
- **去掉转盘**：展示窗里是暖米色摄影棚背景，脚下只有一块渐隐软落影 + 真实投影（只接收阴影的透明地面），三点布光不变；模型对角线统一缩放到 3.3
- **做法**：展示窗仍是战场 renderer 的 viewport + scissor；窗口四周和盒子其余部分的奶油色，由 `.ars-pv` 的超大外扩阴影提供（盒子 `overflow:hidden` 裁掉多余），窗口圆角也靠它；压暗层用 `clip-path` 在窗口矩形处挖洞。不再需要旧的整块面板底板挖洞
- 兵工厂打开时隐藏右上角的旋转 / 视距 / 换图按钮（原先会透到展示窗上）
- `src/battle/arsenal.js`、`src/battle/battle.css`；`index.html`：`GM_VERSION` `0.44` → `0.45`

## 0.44

- **展台改版（暖米色摄影棚 + 玩具底座）**：背景换成暖米色径向渐变（和奶油面板同色系，略深，带暗角）；脚下是有厚度的玩具底座（深蓝灰底 + 军队色腰线 + 奶油白台面 + 台面细环 + 一圈刻度，刻度随模型一起转，才看得出在转；军队色随「蓝军 / 红军」变）；底座下面一块渐隐的暗斑当落影
- **三点布光**：暖色主光（投影，软边）+ 冷色补光 + 背后轮廓光（给模型边缘勾亮边）
- **取景重做**：按「底座 + 模型」总高度和底座直径算相机距离，底座和模型都完整入镜；模型对角线统一放大到 3.5（原 4.0）
- **「机械兵」改名「反坦克兵」**（引擎 id 仍是 `mech`，模型本来就是反坦克步兵）：`rules/data.js`、`engine-map.js`、兵工厂卡片图标由「机」改「反」
- `src/battle/arsenal.js`、`src/battle/battle.css`；`index.html`：`GM_VERSION` `0.43` → `0.44`

## 0.43

- **转台拖动修好**：虚拟横屏（舞台旋转 90°）下，手指的横向滑动落在逻辑坐标的另一个轴上，原来只把横向分量交给 `stage.vec` 换算，结果永远是 0；现在 x、y 两个分量都交给它。无头浏览器里拖动验证模型会跟着转（那里舞台没旋转，虚拟横屏下的拖动要你真机确认）
- **展台改成纯黑虚空**（`#030405`），去掉转盘：脚下一圈很淡的蓝灰柔光（有"踩着地"的感觉）+ 只接收阴影的透明地面（单位的影子投在柔光上，能看见）；单位在原地自转，光源不动，效果等同相机绕着模型转
- `src/battle/arsenal.js`、`src/battle/battle.css`；`index.html`：`GM_VERSION` `0.42` → `0.43`

## 0.42

- **兵工厂生产界面（风格 B 玩具盒）**：新增 `src/battle/arsenal.js`，样式在 `src/battle/battle.css` 末尾。战场上点「当前回合一方」的兵工厂弹出：左边 11 个兵种卡片（价格 / 买不起置灰 / 防空导弹"暂不可生产"），右边选中单位的**高精度模型转台**（自动慢转、手指拖动旋转）+ 移动 / 射程 / 弹药 / 视野 + 生产按钮；右上资金、✕ 关闭；「蓝军 / 红军」按钮仅供验收美术（切换军队色看模型）
- 转台不开第二个画布：用战场同一个 renderer，在右侧透明留空区对应的屏幕矩形里（viewport + scissor）画一个独立小场景；面板底板和背景压暗层用 `clip-path` 在该矩形挖洞，战场画布才能透出来；虚拟横屏下也成立（用 DOM offset 链取舞台内坐标）
- 预览用的是原版 / 基线高精度模型（步兵 V6 基线、反坦克步兵基线、轻 / 中 / 重坦、自行火炮），不是战场上的批量性能版；每个模型按对角线统一放大到占满转台；快速侦察车、装甲运输车、火箭炮、防空炮、防空导弹显示"尚未建模"
- **「生产」目前只是演示**（提示"不扣钱、不出兵"），等你对界面和模型特写满意后再接引擎 `produce()` 和出兵
- `src/battle/main.js`：创建 / 销毁兵工厂；界面打开时每帧重画战场 + 转台
- `index.html`：`GM_VERSION` `0.41` → `0.42`

## 0.41

- **收入改版**：总部 / 大城市 / 兵工厂 / 机场 / 船坞 每回合 1000，小城市 700（原来总部、大城市 1500，小城市 1000）；理由：钱来得太容易，前期抢城没有意义。数值在 `src/rules/data.js` 的 `TERRAINS`
- **开局资金 0**（`level1.js` 的 `START.funds`）：第 1 天蓝方领一次收入 3000（总部 + 2 兵工厂），红方轮到时领 3000
- 测试同步：`check-rules.mjs` 收入用例改新数字并加小城市 700 一项；`check-engine-map.mjs` 改为 +3000
- `index.html`：`GM_VERSION` `0.40` → `0.41`

## 0.40（新窗口第 1 版）

- **关卡接上规则引擎（只显示，还不能操作）**：新增 `src/game/engine-map.js`（预设 → 引擎：地形逐格对应 `TERRAINS` id、建筑归属 `owners`、开局资金、起始部队；纯数据，Node 里可测）。引擎坐标 = 世界格坐标减棋盘左上角，换算函数 `toEngine` / `toWorld`；玩家 0 = 蓝（西，先手）、1 = 红（东）
- **开局设定**：`src/game/levels/level1.js` 顶部 `START = {funds: 5000, army: ['inf','inf','mech','tank']}`【暂定】；蓝方起始部队随机落在总部周围 2–4 格内（避开基地一圈、山 / 沙漠 / 沼泽 / 河 / 桥），红方左右镜像，所以双方完全对称；第 1 天蓝方再领一次收入（总部 1500 + 2 兵工厂 2000 = 3500，显示 8500 / 5000）
- **战场显示**：开局单位按引擎状态摆出来（步兵、机械兵 = 反坦克步兵模型、轻坦；蓝军面朝东、红军面朝西）；左下角信息栏加一行 `第 N 天 · 蓝方回合 · 资金`；点格子时显示建筑归属（蓝方 / 红方 / 中立），点到单位显示兵种、血量（格）、弹药
- 新增 `tools/check-engine-map.mjs`（40 个种子：地形合法、建筑归属 1 总部 + 2 兵工厂 / 中立 2 大 + 6 小、起始部队站在合法格且双方镜像、每个单位都能动），并入 `npm test`
- `src/battle/main.js`：创建引擎、把单位规格写进 `preset.layout.units`；调试对象 `window.battle` 多了 `game`
- `index.html`：`GM_VERSION` `0.39` → `0.40`

## 0.39（上个窗口最后一版，只改文档）

- 更新 `docs/HANDOFF.md` 到本窗口的最终状态：战场并入主页（单文档）、规则引擎与经济（`src/rules/`）、格子光圈与地形取样、界面风格方向、顶部固定 52px、状态栏图标结案、待你决定清单、0.40 起的路线图、本地无头浏览器验证方法与新教训
- `index.html`：`GM_VERSION` `0.38` → `0.39`；**新窗口从 0.40 起**

## 0.38

- **光圈贴合各种地形**：`src/game/world.js` 新增 `surfaceY(cx, cz, x, z)`（任意点的可见表面高度：桥面 → 桥面高度；山体 → 山脚；沙漠 → 沙丘起伏；河 / 海 → 水面；海岸格 → 锚点高度；沼泽 → 0；其余 → 平地 / 建筑底面）。`src/battle/cursor.js` 的 `show(x, z, kind, sample)` 改为取样函数：光圈整体放在格子中心的表面上，四个护角和底色（8×8 细分）各自贴合自己位置的高度，沙丘起伏、桥面都对得上
- **点桥选中桥格**：`cellFromRay` 对桥面高度再取一次（桥面比地面高，原来按地面取会选到桥后面的格子）
- 验证：沙漠 / 海面 / 桥面真实点击截图确认；本关种子 7 没有"河"格，河面走同一套水面取样，没有单独截图
- `src/battle/main.js` 改用 `surfaceY`；`index.html`：`GM_VERSION` `0.37` → `0.38`

## 0.37

- **光圈对齐山体**：`src/game/world.js` 新增 `baseY(cx, cz)`（格子的地面高度；山体取山脚，其余同 `groundY`）。原来光圈取 `groundY`，对山体返回的是山顶站位点，光圈浮在山顶高度，透视下偏上
- **光圈贴地 + 挡住的部分半透明**：`src/battle/cursor.js` 光圈画在真实地面上，没被挡的部分实心，被建筑 / 山体挡住的部分用半透明显示（`GreaterDepth`），底色层也不再盖在建筑上；护角略收细，粗细集中在 `SIZE`（`arm` / `thick` / `edge`），半透明程度 `GHOST`；`src/battle/main.js` 改用 `baseY`
- 建筑标记（菱形水晶）保持始终可见
- `index.html`：`GM_VERSION` `0.36` → `0.37`

## 0.36

- **格子光圈升级**：新增 `src/battle/cursor.js`（`createCursor`、`COLORS`），`src/battle/main.js` 改用它（替换原来的黄色细线方框）。四个转角厚护角（浅金色 + 深蓝描边），点中时从大一圈"落下"弹一下，之后轻微呼吸；点到建筑时护角更粗、底色更亮，并在建筑上方多一颗自转、上下浮动的菱形标记。光圈显示时约 30 帧/秒重画，不显示时仍按需渲染
- 光圈颜色集中在 `COLORS`，以后单位选中、移动范围等沿用，界面和战场保持同一风格
- `index.html`：`GM_VERSION` `0.35` → `0.36`

## 0.35

- **界面风格对比页**（测试页，不影响游戏）：新增 `tests/ui-style.html`、`src/app/ui-style.js`、`src/app/ui-style.css`。同一套兵工厂界面（左：11 个兵种卡片，含价格 / 置灰 / "暂不可生产"；右：转台预览 + 移动 / 射程 / 弹药 / 视野 + 生产按钮）× 三套主题：A 战术终端、B 玩具盒、C 折中；可切蓝 / 红军色。单位数据取自规则引擎；防空炮 / 防空导弹显示"尚未建模"；转台是占位方块，可拖动旋转，不拖时自动慢转
- 选定风格后整理成全游戏统一的界面规范（兵工厂、单位信息、建筑信息共用）
- `index.html`：`GM_VERSION` `0.34` → `0.35`

## 0.34

- **经济规则**：`src/rules/data.js`（11 个单位造价；地形收入：总部 / 大城市 1500，小城市 / 兵工厂 / 机场 / 船坞 1000；`incomeMul` 整体收入倍率）、`src/rules/engine.js`（`owners` 建筑归属、`funds` 开局资金、回合开始领收入、`produce()` 在自己的兵工厂生产，每座每回合 1 个，新单位本回合不能行动）
- 造价大体沿用高战2，改了三处：装甲运输车 5000→4000，重坦 22000→20000，自行火炮 6000→7000；防空导弹暂不可生产（没有空军 / 海军时它无目标），防空炮对陆军有伤害，可以生产
- `tools/check-rules.mjs` 增加 4 项经济测试（共 15 项）；`index.html`：`GM_VERSION` `0.33` → `0.34`

## 0.33

- **规则引擎骨架**（纯数据 + 纯函数，不依赖画面；战场画面这一版不变）：新增 `src/rules/data.js`（11 个陆军单位、17 种地形的移动消耗与防御星、高战2 伤害表、配置开关、军队风格）、`src/rules/combat.js`（伤害公式、选武器）、`src/rules/engine.js`（移动、攻击与反击、间接火力、弹药、沼泽掉血、回合切换、歼灭胜负）
- 伤害公式同高战2（无指挥官）：基础伤害 × 攻方血量 ×（200 −（守方系数 + 地形星 × 守方血量））；指挥官改为"军队风格"，系数直接进公式，默认均衡型（攻守都 ×1）
- 单位造价留空（不照抄原作），合流返现（`joinRefund` 0.9）等定价后实现
- 草案项（可直接改 `data.js`）：沙漠、沼泽、断崖的移动消耗与防御；防空导弹移动力取 4
- 新增 `tools/check-rules.mjs`（11 项测试），并入 `npm test`；`index.html`：`GM_VERSION` `0.32` → `0.33`

## 0.32

- 测试页顶部固定距离 55px → 52px：`src/app/ui.css`（`--top-safe`；错误条随之变为 52+52）
- 主页菜单离岛侧边缘至少 52px：`home.css`（`--pad-l: max(5vw, 56px)`：按钮倾斜后最靠边的角约退进 4px，实测可见边缘 ≈ 52px；标题同步右移几像素）；`index.html`：`GM_VERSION` `0.31` → `0.32`

## 0.31

- **测试页直接加到主屏幕时顶部空白**：`tests/units-terrain.html` 缺少 `apple-mobile-web-app-capable` 和 `status-bar-style=black-translucent`（`index.html`、`orientation.html` 都有），iOS 按默认状态栏样式把内容推到状态栏下面（inner 少了约 62px）。从主页跳转过去没问题，是因为沿用了主页已经建立的窗口样式。补上这几行 meta；已经加到主屏幕的旧图标要删掉重新添加才会生效。
- `index.html`：`GM_VERSION` `0.30` → `0.31`

## 0.30（新窗口第一版）

- **战场并入主页，整个游戏只有一个 html**（不再有页面跳转，系统边缘滑动前进 / 后退手势没有历史可翻）：删除 `battle.html`；`index.html`（新增 `#homeView` / `#battle` 两个视图、`<!--GM-BOOT self="1"-->` 只生成 importmap）、`home.js`（单人对战 = 切换视图并按需 `import('./src/battle/main.js')`；舞台只创建一次、两个视图共用；开发直达 `index.html?go=battle&seed=N&debug=1`）、`home.css`（`#homeView`）、`src/battle/main.js`（改成 `mountBattle` / `unmountBattle`，退出和「换图」时停循环、摘监听、释放显存与 WebGL 上下文；「换图」原地重建，不再刷新页面）、`src/battle/battle.css`（全部挂在 `#battle` 下）、`src/battle/stage.js`（新增 `offChange`）、`tools/stamp.mjs`（支持 `self="1"` 和无入口页面）
- `tests/units-terrain.html` 顶部不再用 `env(safe-area-inset-top)`（从网址直接打开时顶部会多出空白）：`src/app/ui.css`（新增 `--top-safe:55px`，`#hud`、`#err` 用它）、`tests/units-terrain.html`（`#bFold`）；原来多出来的 +8px 间距一并去掉
- 文档：`README.md`、`docs/HOME.md`、`docs/ARCHITECTURE.md` 同步页面结构（`docs/HANDOFF.md` 按习惯等本轮结束时再整理）
- `index.html`：`GM_VERSION` `0.29` → `0.30`

## 0.29
- `tests/units-terrain.html` 顶部加安全区（竖屏下免得被灵动岛挡）：`src/app/ui.css`（`#hud`、`#err`）、`tests/units-terrain.html`（`#bFold`）的 `top` 加 `env(safe-area-inset-top)`
- `docs/HANDOFF.md` 按本窗口结果整理：新窗口从 0.30 起；§5 改写（舞台方案、全屏规则、安全区例外、排查工具、沿革）；§7 新增“竖屏状态栏图标”未解决项；§10 教训；§3 / §4 补自动应用工作流
- `index.html`：`GM_VERSION` `0.28` → `0.29`

## 0.28
- `tests/units-terrain.html` 竖屏底部留白：`src/app/ui.css`（`html,body` / 画布改 100vw×100vh，底部条 `bottom:calc(100% - 100vh)`）、`src/app/main.js`（画布尺寸、点选、拖动换算用 100vw×100vh 探针量出的 `vp`，不再用 `innerWidth/innerHeight`；横竖屏切换时重新测量；HUD 末行显示 100vh / inner 数字）
- `index.html`：`GM_VERSION` `0.27` → `0.28`

## 0.27
- 主页去掉「换边」按钮：`index.html`、`home.css`、`home.js`（换边只在战场页里做，选择共用；`src/battle/stage.js` 回到前台 / 页面从缓存恢复时重新读取选择，所以在战场页换边后回主页会自动跟着变）
- 主页版本号：往里挪（`right:34px; bottom:24px`，避开屏幕圆角）、加粗、白字黑描边，叠在背景图上也看得清
- `src/battle/stage.js`、`src/battle/orientation-test.js`：排查开关（测量方式 / 关闭旋转 / 容器）不再存 `localStorage`，只在当前页面有效，刷新恢复默认（旋转开、容器 100vh、测量 vh），避免测试留下的状态影响别的页面
- `src/battle/battle.css`：注释同步；`index.html`：`GM_VERSION` `0.26` → `0.27`

## 0.26（舞台并回战场页和主页）
- 根因（0.25 测试页验证）：`html,body` 写成 `position:fixed; inset:0` / `height:100%` 时，竖屏独立窗口里只有 812（比屏幕矮 62），底部留白；改成 `width:100vw; height:100vh` 就铺满
- 战场页并回舞台：`battle.html`（整页放进 `#stage`，去掉竖屏提示 `#land`，新增「换边」）、`src/battle/main.js`（画布 / 相机尺寸用 `stage.w/h`，指针坐标用 `stage.toLogical`，长按「换边」0.8 秒开现场诊断）、`src/battle/battle.css`（`html,body` 改 100vw×100vh，界面层相对舞台定位）
- 主页并回舞台：`index.html`（整页放进 `#stage`，去掉竖屏提示层，背景改 `<img id="bg">`，新增「换边」）、`home.css`（`html,body` 改 100vw×100vh；`vw/vh` 改 `--sw/--sh`；去掉 `env(safe-area-*)`）、`home.js`（动态加载 `stage.js`、按舞台比例选背景、换边、长按诊断）
- `src/battle/orientation-test.js`：「容器」开关默认 100vh
- `index.html`：`GM_VERSION` `0.25` → `0.26`

## 0.25（回退 + 单独排查）
- 回退：战场页、主页恢复为 v8 的做法（真横屏；竖屏显示“请横屏使用”），不再用舞台——0.21 起并入舞台后竖屏出现黑边，原因没查清。涉及 `battle.html`、`src/battle/main.js`、`src/battle/battle.css`、`index.html`、`home.css`、`home.js`，相对 v8 只去掉了 `env(safe-area-*)`
- 舞台只留在 `tests/orientation.html` 单独排查：新增「旋转 开/关」「容器 fixed/100vh」两个开关（`gm.norot`、`gm.root`），配合诊断面板的测量方式，一次摸清黑边出在哪；`src/battle/stage.js` 新增 `setNoRot()`
- `docs/HANDOFF.md`、`docs/HOME.md` 同步；`index.html`：`GM_VERSION` `0.24` → `0.25`

## 0.24
- 竖屏黑边的现场诊断（0.23 的 100vh 探针没解决）：`src/battle/stage.js` 测量方式可切换（`gm.measure`：vh / lvh / svh / dvh / inner / screen / fixed，默认 vh），新增 `stageDebug()`（画各单位量到的屏幕边界 + 数字面板 + 切换按钮）和 `onLongPress()`
- 长按「换边」0.8 秒打开诊断：`src/battle/main.js`（战场页）、`home.js`（主页）；`src/battle/orientation-test.js`（测试页打开就带）
- `index.html`：`GM_VERSION` `0.23` → `0.24`

## 0.23
- 修竖屏伪横屏的黑色空白：`src/battle/stage.js` 量尺寸改用 `100vw×100vh` 隐形探针（`innerHeight` 在 iOS 独立窗口竖屏下比真实屏幕矮一截）；舞台上新增 CSS 变量 `--sw` / `--sh`（舞台宽 / 高的 1%）
- 主页并入虚拟横屏舞台：`index.html`（整页放进 `#stage`，去掉竖屏提示层，背景改成 `<img id="bg">`，新增「换边」按钮）、`home.css`（`vw/vh` 全改 `--sw/--sh`，`fixed` 改 `absolute`，去掉所有 `env(safe-area-inset-*)`）、`home.js`（动态加载 `stage.js`、按舞台比例选背景图、换边按钮、去掉“请横屏”文字）
- `src/battle/orientation-test.js`：HUD 第一行多打 `inner` / `screen` / `client` 数字，排查黑条用
- `index.html`：`GM_VERSION` `0.22` → `0.23`

## 0.22（只动工具和文档，运行文件没变）
- 新增 `.github/workflows/apply-package.yml`、`tools/apply-package.py`：手机网页把升级包 / 完整包 zip 传到仓库根目录，机器人自动解压、覆盖、删文件（`.github/workflows/` 里的文件机器人改不了，仍要手动传）
- `tools/pack.mjs`：升级包里多一个 `_delete.txt`（要删的文件清单，给自动应用用），升级说明加了手机上传的提示
- `README.md` 加「手机网页更新」，`docs/HANDOFF.md` 开机清单第 4 条改为"完整包 + 升级包"
- `index.html`：`GM_VERSION` `0.21` → `0.22`

## 0.21
- 虚拟横屏并入战场页：`battle.html`（整个页面放进 `#stage`，删除竖屏提示 `#land`，新增「换边」按钮）、`src/battle/main.js`（画布和相机尺寸用 `stage.w/h`，指针坐标用 `stage.toLogical`）、`src/battle/battle.css`（`#ui` / `#err` / `#loading` / 画布改为相对舞台定位）
- `index.html`：`GM_VERSION` `0.20` → `0.21`
- `tools/pack.mjs`：升级包里的"更新后"提示，遇到 `index.html` 已在包内时不再叫你手动改版本号

## 0.20（新窗口第一版；从这一版起交付完整仓库 zip，文件名带版本号）
- 战场 / 测试页不再处理安全区（灵动岛、手势区）：`src/battle/stage.js` 去掉安全区探测（`insets`、`--sa-*`、`insetsToLogical`）；`src/battle/battle.css`、`src/app/ui.css`、`tests/orientation.html`、`tests/units-terrain.html` 里的 `env(safe-area-inset-*)` 改成固定边距；`src/battle/orientation-test.js` 去掉对应显示
- `battle.html` 补 `apple-mobile-web-app-status-bar-style=black-translucent`（与主页、横屏测试页一致）
- 删除 `tools/bundle.mjs`（离线单文件打包，已不适用）；仓库根目录多余的 `升级说明.md` 不再放进包
- `index.html`：`GM_VERSION` `0.1.0` → `0.20`
- 虚拟横屏定为 iPhone 的正式方案，iPad 用真横屏（`docs/HANDOFF.md` §5）；并入战场页是下一步

## v8（旧窗口的收尾版，之后新窗口从 0.20 起）
- 新增 `docs/HANDOFF.md`（唯一必读的交接文档）、`docs/HOME.md`（并入主页开发文档）
- 旧开发文档改名并归档：`docs/archive/钢铁经线_开发文档.md` → `docs/archive/方寸战线_开发文档_测试阶段.md`（旧文件请删除）
- `docs/ARCHITECTURE.md` §2、§8 更新，新增 §9、§10；`docs/ART_PACKAGES.md` 更新
- 新增 `tools/manifest.mjs`、`tools/pack.mjs` 与 `docs/manifests/`（版本快照，之后可一键生成"从任意版本升级"的升级包）
- `README.md` 加文档索引

## v7
- 新增 `src/battle/stage.js`：虚拟横屏舞台（iPhone PWA 不能锁横屏时，系统竖屏就把画面转 90°）
- 新增 `src/battle/orientation-test.js`、`tests/orientation.html`：虚拟横屏真机测试页
- `src/app/main.js`、`tests/units-terrain.html`：测试页加「横屏测试」入口；三个页面里的文件清单增加新文件（`battle.html`、`tests/*.html`）

## v6
- `src/game/levels/level1.js` 第一关生成器重写：水域也随机（大湖 / 不规则湖 / 左右两池 / 没有湖）、河 + 公路桥、湖上跨海桥、基地行号与城市位置随机
- `src/game/map-builder.js` 岛屿图支持内陆河
- `src/game/world.js` 沼泽停留回合下沉接口 setMireTurns
- `src/battle/main.js` 点按格子能识别桥
- `src/app/main.js`、`tests/units-terrain.html` 测试页：沼泽停留回合按钮

## v5
- `src/art/terrain/desert-swamp/expansion-terrain.js` 沼泽按格指定道具（propVariant）
- `src/game/world.js` 沙漠每格不同高度、沼泽道具随机与站位深浅
- `src/game/map-builder.js` 纯陆地图可建；新增「沙漠沼泽」测试图
- `src/app/main.js` 测试页地图列表加入「沙漠沼泽」
- `docs/ART_PACKAGES.md` 登记上面的改动

## v4
- 沙漠、沼泽接入战场（新增 `src/art/terrain/desert-swamp/` 三个文件；`world.js`、`map-builder.js`、`level1.js`、`src/battle/main.js` 等）
- 战场页不再显示版本号
