import * as THREE from 'three';
import {createTank} from './units/tank-family.js';
import {createArtillery} from './units/artillery-v2_0.js';
import {createInfantryActor} from './units/soldier-instance.js';
import {createTreePine, createTreeBroad, createMountainRegion, createRoadStraight, createRoadBend, createRoadT, createRoadCross, createRoadEnd} from './terrain/terrain-nature.js';
import {createBuildingDisplay, setBuildingDisplayState, setBuildingAccent, getBuildingAccessories} from './terrain/terrain-buildings.js';
import {createAirport, createDockyard, setDockyardState} from './terrain/terrain-transport.js';
import {PALETTE as P, MAT_TERRAIN, MAT_ACCENT} from './terrain/palette.js';

// 钢铁经线 · 单位 × 地形 测试场景（无 DOM，可在 Node 里做结构检查）
export const S = 1.8 / 4.21;          // 备忘录里的统一缩放：步兵高 4.21 → 1.8
export const MTN_STAND = 0.55;        // v0.3 山格站位面高度
export const STAND_R = 0.8;           // 平地站位圈半径
export const ART_K = 0.88;            // 自行火炮相对统一缩放的系数：车体长/宽与轻坦对齐（轻坦车体 3.63×2.45，火炮 4.07×2.81）
export const CULL_R = 2.8;            // 单位级视锥剔除半径（备忘：阴影开时放宽到 2.8）
export const ART_ELEV = 50;           // 火炮默认仰角（原模型默认 30°，上限 65°）

const MOUNTAIN = [[1, -3], [2, -3], [2, -2], [-4, -3]];
// 道路网：由相邻关系自动选件（直 / 弯 / T / 十字 / 终点）并旋转
const ROAD_NET = [[-4, 0], [-3, 0], [-2, 0], [-1, 0], [0, 0], [1, 0], [2, 0], [3, 0], [1, 1], [1, 2], [1, 3], [3, 1], [3, 2], [-1, -1], [-1, 1], [-1, 2]];
const DIRS = {E: [1, 0], N: [0, -1], W: [-1, 0], S: [0, 1]}, SEQ = ['E', 'N', 'W', 'S'];
const rotDir = (d, k) => SEQ[(SEQ.indexOf(d) + k) % 4];           // rotation.y = k·90° 时 d 落到哪个方向
export function roadPieces(cells) {
  const set = new Set(cells.map(c => c.join(',')));
  return cells.map(([cx, cz]) => {
    const conn = SEQ.filter(d => set.has((cx + DIRS[d][0]) + ',' + (cz + DIRS[d][1])));
    const match = (def) => { for (let k = 0; k < 4; k++) { const r = def.map(d => rotDir(d, k)); if (r.length === conn.length && r.every(d => conn.includes(d))) return k; } return -1; };
    let kind, k;
    if (conn.length === 4) { kind = 'cross'; k = 0; }
    else if (conn.length === 3) { kind = 't'; k = match(['W', 'E', 'S']); }
    else if (conn.length === 2 && conn[0] !== rotDir(conn[1], 2)) { kind = 'bend'; k = match(['S', 'E']); }
    else if (conn.length === 2) { kind = 'straight'; k = match(['E', 'W']); }
    else { kind = 'end'; k = conn.length ? match(['S']) : 0; }
    return {cx, cz, kind, k, conn};
  });
}
const ROAD_MAKE = {straight: createRoadStraight, bend: createRoadBend, t: createRoadT, cross: createRoadCross, end: createRoadEnd};
const FOREST = {x: [-3, -1], z: [-4, -2]};                                         // 成片树林（3×3）
const FOREST_EXTRA = [[2, -1], [3, -5], [0, -5], [-1, 4], [-4, 3], [-4, 4]];       // 孤立林格（单格）与两格小树丛
const FOREST_SET = new Set(FOREST_EXTRA.map(c => c.join(',')));
for (let x = FOREST.x[0]; x <= FOREST.x[1]; x++) for (let z = FOREST.z[0]; z <= FOREST.z[1]; z++) FOREST_SET.add(x + ',' + z);
const isForest = (x, z) => FOREST_SET.has(x + ',' + z);
const forestNbrs = (x, z) => [[1, 0], [-1, 0], [0, 1], [0, -1]].filter(([dx, dz]) => isForest(x + dx, z + dz)).length;
const TRUNK_R = .14;                                                                 // 树干半径：挤开只避让树干，树冠可以盖到单位
export const MAP = {x: [-4, 3], z: [-5, 4]};                       // 可玩棋盘（格坐标，含端点）
const SEA = new Set([[2, 3], [3, 3], [2, 4], [3, 4]].map(c => c.join(',')));   // 测试用海（东南角 2×2）
const isSea = (cx, cz) => SEA.has(cx + ',' + cz);
const WATER_Y = -0.3, BASE_Y = -1.6;
const BUILD_LIST = [
  {type: 'bld_hq', cell: [0, 3], owner: 'blue', name: '蓝总部'},
  {type: 'bld_hq', cell: [3, -4], owner: 'red', name: '红总部'},
  {type: 'bld_city_large', cell: [-3, 1], owner: 'neutral', name: '大城市'},
  {type: 'bld_city_small', cell: [0, -2], owner: 'neutral', name: '小城市'},
  {type: 'bld_factory', cell: [-4, 1], owner: 'blue', name: '蓝兵工厂'},
  // R3 交通建筑：机场随视角转向（跑道在场景里朝向无关紧要）；船坞固定朝南，通道口对着东南角的海
  {type: 'bld_airport', cell: [-2, 3], owner: 'neutral', name: '机场', stand: [0, .45], y: .018},
  {type: 'bld_dockyard', cell: [2, 2], owner: 'neutral', name: '船坞', stand: [0, .40], y: .087, follow: false},
];
const DOCK_CELL = BUILD_LIST.find(b => b.type === 'bld_dockyard').cell;
const DOCK_HALF_W = .55, DOCK_BACK_Z = -.2;          // 船坞水道：半宽 / 码头后沿（局部 z，水道从这里向南开口）
const isDock = (cx, cz) => cx === DOCK_CELL[0] && cz === DOCK_CELL[1];
const ACCENT_COL = {neutral: 0xc4c8cc, blue: 0x2368cb, red: 0xc4402f};
const OWNER_NEXT = {neutral: 'blue', blue: 'red', red: 'neutral'};
export const TREE_LABELS = ['树木:现状', '树木:挤开', '树木:透视'];
export const SIZE_LABELS = ['尺寸:原始比例', '尺寸:战棋比例', '尺寸:步兵小队'];
export const CLS_DEFAULT = {inf: 1.3, light: 1.0, medium: .92, heavy: .8, art: 1.0};     // 战棋比例：各兵种独立缩放（不强求和坦克成比例）
const SQUAD_OFF = [[0, 1.4], [-1.25, -1.0], [1.25, -1.0]];                          // 方案4：小队站位（模型单位，z 向前）

const UNITS = [
  {k: 'tank', type: 'medium', team: 'blue', c: [-2, 0], face: Math.PI / 2, name: '蓝中坦（在路上）'},
  {k: 'tank', type: 'heavy', team: 'blue', c: [0, 2], face: Math.PI, name: '蓝重坦'},
  {k: 'tank', type: 'light', team: 'blue', c: [2, 1], face: Math.PI, name: '蓝轻坦'},
  {k: 'art', team: 'blue', c: [-3, 2], face: Math.PI, name: '蓝火炮'},
  {k: 'inf', team: 'blue', c: [1, 0], face: Math.PI, name: '蓝步兵（在路上）'},
  {k: 'inf', team: 'blue', c: [-1, 1], face: Math.PI, name: '蓝步兵'},
  {k: 'tank', type: 'medium', team: 'red', c: [3, -1], face: 0, name: '红中坦'},
  {k: 'tank', type: 'light', team: 'red', c: [0, -1], face: 0, name: '红轻坦'},
  {k: 'art', team: 'red', c: [-4, -1], face: 0, name: '红火炮'},
  {k: 'inf', team: 'red', c: [-2, -3], face: 0, name: '红步兵（在林中）'},
  {k: 'inf', team: 'red', c: [1, -3], face: 0, name: '红步兵（上山）'},
  {k: 'inf', team: 'red', c: [2, -3], face: 0, name: '红步兵（上山）'},
];

function rng(seed) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

export function triCount(obj) {
  let n = 0;
  obj.traverse(o => { if (o.isMesh) { const g = o.geometry; n += (g.index ? g.index.count : g.attributes.position.count) / 3; } });
  return Math.round(n);
}

// 位置哈希噪声（确定性，边界处相邻段天然连续）
const hash2 = (a, b) => { let h = Math.imul(Math.floor(a * 1000) * 374761393 + Math.floor(b * 1000) * 668265263, 1274126177); h ^= h >>> 13; h = Math.imul(h, 1103515245); h ^= h >>> 16; return (h >>> 0) / 4294967296; };
const smooth = t => t * t * (3 - 2 * t);
const vn = (x, y) => { const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi, g = (i, j) => hash2(i, j) , u = smooth(xf), v = smooth(yf); const a = g(xi, yi), b = g(xi + 1, yi), c = g(xi, yi + 1), d = g(xi + 1, yi + 1); const t0 = a + (b - a) * u, t1 = c + (d - c) * u; return t0 + (t1 - t0) * v; };
const fbm = (x, y) => vn(x, y) * .6 + vn(x * 2.1 + 7.3, y * 2.1 + 3.1) * .3 + vn(x * 4.3 + 1.7, y * 4.3 + 9.2) * .1;

// 棋盘：连续草地 + 海 + 岸壁；沙盘模式再加"地层截面"边缘与底座
function makeBoard(sandbox, sampleH, floorTint) {
  const pos = [], col = [], c3 = new THREE.Color();
  const tri = (a, b, c, color, out) => {
    const ab = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], ac = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
    const n = [ab[1] * ac[2] - ab[2] * ac[1], ab[2] * ac[0] - ab[0] * ac[2], ab[0] * ac[1] - ab[1] * ac[0]];
    if (n[0] * out[0] + n[1] * out[1] + n[2] * out[2] < 0) { const t = b; b = c; c = t; }
    pos.push(...a, ...b, ...c); c3.set(color); for (let i = 0; i < 3; i++) col.push(c3.r, c3.g, c3.b);
  };
  const quad = (p0, p1, p2, p3, color, out) => { tri(p0, p1, p2, color, out); tri(p0, p2, p3, color, out); };
  const UP = [0, 1, 0];
  const x0c = sandbox ? MAP.x[0] : -8, x1c = sandbox ? MAP.x[1] : 7, z0c = sandbox ? MAP.z[0] : -8, z1c = sandbox ? MAP.z[1] : 7;
  const land = (cx, cz) => cx >= x0c && cx <= x1c && cz >= z0c && cz <= z1c && !isSea(cx, cz);
  for (let cz = z0c; cz <= z1c; cz++) for (let cx = x0c; cx <= x1c; cx++) {
    const xa = cx * 2 - 1, xb = cx * 2 + 1, za = cz * 2 - 1, zb = cz * 2 + 1;
    if (isSea(cx, cz)) { quad([xa, WATER_Y, za], [xa, WATER_Y, zb], [xb, WATER_Y, zb], [xb, WATER_Y, za], 0x2a86b8, UP); continue; }
    let gc = ((cx + cz) & 1) ? P.grass : P.grassAlt;
    if (floorTint) {
      const inF = isForest(cx, cz), inB = BUILD_LIST.some(b => b.cell[0] === cx && b.cell[1] === cz);
      if (inF) gc = c3.set(gc).lerp(new THREE.Color(0x3f7a28), .62).getHex(); else if (inB) gc = c3.set(gc).lerp(new THREE.Color(0xb9b7a0), .55).getHex();
    }
    if (isDock(cx, cz)) {   // 船坞格：水道（x∈±DOCK_HALF_W，z 从码头后沿向南）挖成水面，其余仍是草地
      const wx0 = cx * 2 - DOCK_HALF_W, wx1 = cx * 2 + DOCK_HALF_W, zq = cz * 2 + DOCK_BACK_Z;
      quad([xa, 0, za], [xa, 0, zq], [xb, 0, zq], [xb, 0, za], gc, UP);
      quad([xa, 0, zq], [xa, 0, zb], [wx0, 0, zb], [wx0, 0, zq], gc, UP);
      quad([wx1, 0, zq], [wx1, 0, zb], [xb, 0, zb], [xb, 0, zq], gc, UP);
      quad([wx0, WATER_Y, zq], [wx0, WATER_Y, zb], [wx1, WATER_Y, zb], [wx1, WATER_Y, zq], 0x2a86b8, UP);
      quad([wx0, 0, zq], [wx1, 0, zq], [wx1, WATER_Y, zq], [wx0, WATER_Y, zq], 0x8b6b3e, [0, 0, 1]);
      quad([wx0, 0, zq], [wx0, 0, zb], [wx0, WATER_Y, zb], [wx0, WATER_Y, zq], 0x8b6b3e, [1, 0, 0]);
      quad([wx1, 0, zq], [wx1, 0, zb], [wx1, WATER_Y, zb], [wx1, WATER_Y, zq], 0x8b6b3e, [-1, 0, 0]);
      continue;
    }
    quad([xa, 0, za], [xa, 0, zb], [xb, 0, zb], [xb, 0, za], gc, UP);
  }
  // 岸壁：陆地与海相邻的竖直泥土面
  for (const key of SEA) { const [cx, cz] = key.split(',').map(Number);
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      if (!land(cx + dx, cz + dz)) continue;
      const out = [-dx, 0, -dz];                       // 朝向海一侧
      const ex = cx * 2 + dx, ez = cz * 2 + dz;        // 共享边中心
      const t = dx ? [0, 1] : [1, 0];
      let A = [ex - t[0], 0, ez - t[1]], B = [ex + t[0], 0, ez + t[1]];
      if (isDock(cx + dx, cz + dz) && dz === -1) {      // 船坞通道口：只在水道两侧留岸壁，口子本身与外面的海连成一片
        const m0 = [ex - DOCK_HALF_W, 0, ez], m1 = [ex + DOCK_HALF_W, 0, ez];
        for (const [P0, P1] of [[A, m0], [m1, B]]) quad(P0, P1, [P1[0], WATER_Y, P1[2]], [P0[0], WATER_Y, P0[2]], 0x8b6b3e, out);
        continue;
      }
      quad(A, B, [B[0], WATER_Y, B[2]], [A[0], WATER_Y, A[2]], 0x8b6b3e, out);
    } }
  if (sandbox) {
    const X0 = MAP.x[0] * 2 - 1, X1 = MAP.x[1] * 2 + 1, Z0 = MAP.z[0] * 2 - 1, Z1 = MAP.z[1] * 2 + 1, STEP = .5;
    const LAND = [[-.12, 0x6fa83a], [-.55, 0x8b6b3e], [-.95, 0x7a5c34], [-1.3, 0x6e6a74], [BASE_Y, 0x5a5662]];
    const WATER = [[-.8, 0x2a86b8], [-1.25, 0x1f6e9c], [BASE_Y, 0x17577f]];
    const wall = (a, b, h0, h1, water, out, seg) => {      // a,b：[x,z] 边上两点；h0,h1：该两点的地表高
      const k = 1 + ((seg & 1) ? .035 : -.035);
      const P0 = y => [a[0], y, a[1]], P1 = y => [b[0], y, b[1]];
      const tint = c => { c3.set(c).multiplyScalar(k); return c3.getHex(); };
      if (water) { let y = WATER_Y; for (const [yl, c] of WATER) { quad(P0(y), P1(y), P1(yl), P0(yl), tint(c), out); y = yl; } }
      else {
        quad(P0(h0), P1(h1), P1(h1 + LAND[0][0]), P0(h0 + LAND[0][0]), tint(LAND[0][1]), out);
        let y0 = h0 + LAND[0][0], y1 = h1 + LAND[0][0];
        for (let i = 1; i < LAND.length; i++) { const yl = LAND[i][0]; quad(P0(y0), P1(y1), P1(yl), P0(yl), tint(LAND[i][1]), out); y0 = y1 = yl; }
      }
    };
    const sides = [
      {out: [-1, 0, 0], n: MAP.z, fix: X0, cells: cz => MAP.x[0] + ',' + cz, along: 'z', cellOf: cz => [MAP.x[0], cz]},
      {out: [1, 0, 0], n: MAP.z, fix: X1, along: 'z', cellOf: cz => [MAP.x[1], cz]},
      {out: [0, 0, -1], n: MAP.x, fix: Z0, along: 'x', cellOf: cx => [cx, MAP.z[0]]},
      {out: [0, 0, 1], n: MAP.x, fix: Z1, along: 'x', cellOf: cx => [cx, MAP.z[1]]},
    ];
    // —— 陆地侧壁：不规则地层（每层边界随位置起伏、厚度变化、层内色彩渐变、嵌石、壁面凹凸、草缘悬垂）——
    const LB_COL = [0x6fa83a, 0x8b6b3e, 0xb59a66, 0x7a5c34, 0x6e6a74, 0x5a5662];   // 草缘 / 土1 / 砾石薄层 / 土2 / 岩1 / 岩2
    const LB_ALT = [0x86b94a, 0x9f7d49, 0xcdb27a, 0x8f6d40, 0x857f8d, 0x6c6775];
    const AMP = [0, .13, .1, .11, .17, .2, 0];
    const altC = new THREE.Color();
    const bounds = (u, h, sd) => {
      const n = (f, k) => (fbm(u * f + sd * 17.3, k * 5.1 + sd * 3.7) - .5) * 2;
      const b = [h, h - (.1 + .13 * fbm(u * 1.3 + sd * 9, 2.2)), -.5 + .2 * n(.55, 1)];
      b.push(b[2] - (.06 + .07 * fbm(u * 2 + sd, 3.3)), -.98 + .22 * n(.5, 2), -1.3 + .18 * n(.6, 3), BASE_Y);
      for (let i = 1; i < 6; i++) b[i] = Math.max(Math.min(b[i], b[i - 1] - .1), BASE_Y + (6 - i) * .08);
      return b;
    };
    const landWall = (sd, si, c) => {
      const P = (u, y, off) => sd.along === 'z' ? [sd.fix + sd.out[0] * off, y, u] : [u, y, sd.fix + sd.out[2] * off];
      const V = (u, i, b) => { const off = i === 0 || i === 6 ? 0 : (fbm(u * 2.4 + i * 13.7 + si * 5, i * 3.1 + si * 2.9) - .5) * AMP[i] + (i === 1 ? .07 : 0); return P(u, b[i], off); };
      const colorOf = (i, u, jit) => { c3.set(LB_COL[i]); altC.set(LB_ALT[i]); c3.lerp(altC, fbm(u * 1.8 + i * 7, i * 5.3 + si * 2)); return c3.multiplyScalar(1 + (hash2(u * 9.1 + i * 17 + jit, si * 3 + i) - .5) * .17).getHex(); };
      const lo = c * 2 - 1, N = 8, STP = 2 / N;
      let prev = null;
      for (let j = 0; j <= N; j++) {
        const u = lo + j * STP, pt = sd.along === 'z' ? [sd.fix - sd.out[0] * .02, u] : [u, sd.fix - sd.out[2] * .02];
        const h = sampleH(...pt), b = bounds(u, h, si), cur = {u, b};
        if (prev) for (let i = 0; i < 6; i++) {
          const p0 = V(prev.u, i, prev.b), p1 = V(u, i, b), p2 = V(u, i + 1, b), p3 = V(prev.u, i + 1, prev.b), um = (prev.u + u) / 2;
          tri(p0, p1, p2, colorOf(i, um, 0), sd.out); tri(p0, p2, p3, colorOf(i, um, 3.7), sd.out);
        }
        prev = cur;
      }
      // 嵌石：贴在土2/岩层里向外微凸的小石块
      for (let k = 0; k < 2; k++) {
        const key = si * 977 + c * 31 + k;
        if (hash2(key, 1.3) < .35) continue;
        const u = lo + .25 + hash2(key, 2.1) * 1.5, h = sampleH(...(sd.along === 'z' ? [sd.fix - sd.out[0] * .02, u] : [u, sd.fix - sd.out[2] * .02])), b = bounds(u, h, si);
        const y = b[4] + (b[5] - b[4]) * (.15 + .7 * hash2(key, 3.7)) + (hash2(key, 4.4) < .5 ? (b[3] - b[4]) * .5 : 0), r = .12 + .15 * hash2(key, 5.5), e = .08 + .09 * hash2(key, 6.6);
        const A = P(u - r, y - .3 * r, 0), B = P(u + r, y - .2 * r, 0), C = P(u + .1 * r, y + .9 * r, 0), D = P(u, y, e);
        const rc = () => { c3.set(0x7d7883).multiplyScalar(.85 + .3 * hash2(key, 7.7 + Math.random() * 0)); return c3.getHex(); };
        const base = rc(); tri(A, B, D, base, sd.out); tri(B, C, D, base, sd.out); tri(C, A, D, base, sd.out);
      }
    };
    let seg = 0;
    for (let si = 0; si < sides.length; si++) { const sd = sides[si];
      for (let c = sd.n[0]; c <= sd.n[1]; c++) {
        const [cx, cz] = sd.cellOf(c), water = isSea(cx, cz), lo = c * 2 - 1;
        if (!water) { landWall(sd, si, c); continue; }
        for (let i = 0; i < 2 / STEP; i++) {
          const u0 = lo + i * STEP, u1 = u0 + STEP;
          const e0 = sd.along === 'z' ? [sd.fix, u0] : [u0, sd.fix], e1 = sd.along === 'z' ? [sd.fix, u1] : [u1, sd.fix];
          wall(e0, e1, 0, 0, true, sd.out, seg++);
        }
      }
    }
    // 底座：一圈略外扩的深色基台 + 顶面台阶
    const E = .2, XA = X0 - E, XB = X1 + E, ZA = Z0 - E, ZB = Z1 + E, DARK = 0x353a42, LEDGE = 0x4a505a, BY = BASE_Y - .3;
    quad([XA, BASE_Y, ZA], [XB, BASE_Y, ZA], [XB, BASE_Y, Z0], [XA, BASE_Y, Z0], LEDGE, UP);
    quad([XA, BASE_Y, Z1], [XB, BASE_Y, Z1], [XB, BASE_Y, ZB], [XA, BASE_Y, ZB], LEDGE, UP);
    quad([XA, BASE_Y, Z0], [X0, BASE_Y, Z0], [X0, BASE_Y, Z1], [XA, BASE_Y, Z1], LEDGE, UP);
    quad([X1, BASE_Y, Z0], [XB, BASE_Y, Z0], [XB, BASE_Y, Z1], [X1, BASE_Y, Z1], LEDGE, UP);
    quad([XA, BASE_Y, ZA], [XB, BASE_Y, ZA], [XB, BY, ZA], [XA, BY, ZA], DARK, [0, 0, -1]);
    quad([XA, BASE_Y, ZB], [XB, BASE_Y, ZB], [XB, BY, ZB], [XA, BY, ZB], DARK, [0, 0, 1]);
    quad([XA, BASE_Y, ZA], [XA, BASE_Y, ZB], [XA, BY, ZB], [XA, BY, ZA], DARK, [-1, 0, 0]);
    quad([XB, BASE_Y, ZA], [XB, BASE_Y, ZB], [XB, BY, ZB], [XB, BY, ZA], DARK, [1, 0, 0]);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.computeVertexNormals();
  const m = new THREE.Mesh(g, MAT_TERRAIN); m.receiveShadow = true; m.name = sandbox ? 'board_sandbox' : 'board_flat';
  return m;
}

// 步兵 V6.7：一个骨架原型 + 每队着色 + 共享几何的实例（units/soldier-instance.js）
function createUnitModel(spec, idx) {
  if (spec.k === 'tank') return createTank(spec.type, {faction: spec.team, batch: true, paint: true});
  if (spec.k === 'art') return createArtillery({faction: spec.team, batch: true, paint: true});
  return null;   // 步兵走 createInfantryActor（需要动画句柄）
}

const BADGE = {light: '轻', medium: '中', heavy: '重', art: '炮', inf: '兵'};
function makeBadge(label, team) {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const x = c.getContext('2d');
  x.fillStyle = team === 'blue' ? '#2f5f9e' : '#a8403a'; x.strokeStyle = '#fff'; x.lineWidth = 6;
  x.beginPath(); x.roundRect(10, 10, 108, 108, 22); x.fill(); x.stroke();
  x.fillStyle = '#fff'; x.font = 'bold 76px -apple-system,PingFang SC,sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText(label, 64, 68);
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({map: tex, depthTest: false, transparent: true}));
  sp.scale.set(.62, .62, 1); sp.renderOrder = 20; return sp;
}

export function buildWorld() {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color('#26333c');
  const sun = new THREE.DirectionalLight(0xfff3d5, 3);
  sun.position.set(-8, 16, 9); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
  Object.assign(sun.shadow.camera, {left: -18, right: 18, top: 18, bottom: -18, near: 1, far: 55});
  sun.shadow.bias = -.0003;
  scene.add(sun, new THREE.HemisphereLight(0xe5efff, 0x67704f, 1.7));

  const state = {infPose: 'idle', infGait: 'run', treeK: 1, mtnK: 1, unitK: 1, artK: ART_K, artElev: ART_ELEV, annexPush: true, yieldOn: false, rings: false, units: true, cull: true, idle: false, badges: false, selected: null, clsK: {...CLS_DEFAULT}, treeMode: 0, sizeMode: 0, floorTint: false, terrBadges: false, camA: 0, viewQuarter: 0, bldFollow: true, sandbox: true};

  const roads = new THREE.Group(); roads.name = 'roads';
  for (const p of roadPieces(ROAD_NET)) { const r = ROAD_MAKE[p.kind](); r.position.set(p.cx * 2, 0, p.cz * 2); r.rotation.y = p.k * Math.PI / 2; roads.add(r); }
  scene.add(roads);

  const mountain = createMountainRegion(MOUNTAIN, 7); scene.add(mountain);
  const mtnSet = new Set(MOUNTAIN.map(c => c.join(',')));
  const bldMap = new Map(BUILD_LIST.map(b => [b.cell.join(','), b]));
  const rc = new THREE.Raycaster(), down = new THREE.Vector3(0, -1, 0);
  const sampleH = (x, z) => { rc.set(new THREE.Vector3(x, 5, z), down); const h = rc.intersectObject(mountain, true)[0]; return h ? Math.max(0, h.point.y) : 0; };
  let ground = null, lastMtnK = -1, lastSand = null, lastTint = false;
  function rebuildBoard() {
    if (ground) { scene.remove(ground); ground.geometry.dispose(); }
    mountain.scale.y = state.mtnK; mountain.updateMatrixWorld(true);
    ground = makeBoard(state.sandbox, sampleH, state.floorTint); scene.add(ground); lastTint = state.floorTint;
    scene.background.set(state.sandbox ? '#1b2227' : '#26333c');
    lastMtnK = state.mtnK; lastSand = state.sandbox;
  }
  rebuildBoard();
  const groundY = (cx, cz) => mtnSet.has(cx + ',' + cz) ? MTN_STAND * state.mtnK : (bldMap.get(cx + ',' + cz)?.y || 0);

  // 树：连片林按抖动网格铺满；孤立林格（周围无林）随机 2–3 棵，避免"只有一棵"的寒酸感
  const trees = [], rand = rng(11);
  const addTree = (x, z) => {
    const v = Math.floor(rand() * 3), sd = Math.floor(rand() * 9999);
    const t = (rand() < .6 ? createTreePine : createTreeBroad)(v, sd);
    t.position.set(x, 0, z); t.rotation.y = rand() * 6.28; scene.add(t);
    trees.push({obj: t, x, z, cx: x, cz: z, hcx: Math.round(x / 2), hcz: Math.round(z / 2), faded: false});
  };
  for (let x = -9 + .4; x < 7; x += .85) for (let z = -11 + .4; z < 9; z += .85) {
    const jx = x + (rand() - .5) * .35, jz = z + (rand() - .5) * .35, cx = Math.round(jx / 2), cz = Math.round(jz / 2);
    if (isForest(cx, cz) && forestNbrs(cx, cz) > 0) addTree(jx, jz);
  }
  for (const [cx, cz] of FOREST_EXTRA.concat([])) {
    if (forestNbrs(cx, cz) > 0) continue;
    const n = rand() < .5 ? 2 : 3, pts = [];
    for (let k = 0; k < 40 && pts.length < n; k++) {
      const px = cx * 2 + (rand() - .5) * 1.5, pz = cz * 2 + (rand() - .5) * 1.5;
      if (pts.every(q => Math.hypot(q[0] - px, q[1] - pz) > .8)) pts.push([px, pz]);
    }
    pts.forEach(q => addTree(q[0], q[1]));
  }

  const roadSet = new Set(ROAD_NET.map(c => c.join(','))), forestHas = isForest;

  // 建筑（按相机象限旋转；空置 = 完整街区，驻扎 = 主楼归位并露出站位锚点）
  const accentMats = {};
  const accentOf = o => accentMats[o] || (accentMats[o] = (m => (m.color.setHex(ACCENT_COL[o]), m))(MAT_ACCENT.clone()));
  // 主建筑正面（朝向系内 z 最大值）。驻军时主建筑会缩回，贴着正面的附件（台阶）要跟着缩
  const measureFront = display => {
    const body = display.getObjectByName('view_facing').getObjectByName('building'); body.updateMatrix();
    let zmax = -Infinity;
    body.traverse(o => {
      if (!o.isMesh) return;
      if (!o.geometry.boundingBox) o.geometry.computeBoundingBox();
      const m = new THREE.Matrix4(); for (let n = o; n && n !== body; n = n.parent) { n.updateMatrix(); m.premultiply(n.matrix); }
      m.premultiply(body.matrix);
      zmax = Math.max(zmax, o.geometry.boundingBox.clone().applyMatrix4(m).max.z);
    });
    return zmax;
  };
  const TRANSPORT_MAKE = {bld_airport: createAirport, bld_dockyard: createDockyard};
  const buildings = BUILD_LIST.map(b => {
    const tr = TRANSPORT_MAKE[b.type];
    let v, acc = [];
    if (tr) { v = new THREE.Group(); v.name = b.type + '_display'; v.add(tr()); v.userData.transport = true; }
    else { v = createBuildingDisplay(b.type); acc = getBuildingAccessories(v); for (const p of acc) p.userData.cur = [p.position.x, p.position.z], p.userData.tgt = [p.position.x, p.position.z]; }
    v.position.set(b.cell[0] * 2, 0, b.cell[1] * 2);
    v.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } }); scene.add(v);
    return {...b, visual: v, acc, front0: tr ? 0 : measureFront(v)};
  });
  const bq = () => state.bldFollow ? state.viewQuarter : 0;
  const bTheta = b => b.follow === false ? 0 : bq() * Math.PI / 2;
  const standPos = (cx, cz) => {
    const b = bldMap.get(cx + ',' + cz);
    if (!b) return [cx * 2, cz * 2];
    const th = bTheta(b), [lx, lz] = b.stand || [0, .45];
    return [cx * 2 + lx * Math.cos(th) + lz * Math.sin(th), cz * 2 - lx * Math.sin(th) + lz * Math.cos(th)];
  };

  // 单位
  const unitsGroup = new THREE.Group(); scene.add(unitsGroup);
  const rings = new THREE.Group(); rings.visible = false; scene.add(rings);
  const units = UNITS.map((spec, idx) => {
    const actors = spec.k === 'inf' ? [0, 1, 2].map(i => { const a = createInfantryActor(spec.team); a.phase = (idx * .31 + i * .27) % 1; return a; }) : null;
    const model = actors ? actors[0].root : createUnitModel(spec, idx);
    const msz = new THREE.Box3().setFromObject(model).getSize(new THREE.Vector3());
    const holder = new THREE.Group(); holder.add(model); holder.rotation.y = spec.face; holder.name = spec.name;
    model.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    let squad = null;
    if (spec.k === 'inf') {   // 小队成员：共享几何和材质，只是多提交几次
      squad = actors.slice(1).map(a => a.root); const lead = SQUAD_OFF[0];
      model.position.set(lead[0], 0, lead[1]);
      squad.forEach((m, i) => { m.position.set(SQUAD_OFF[i + 1][0], 0, SQUAD_OFF[i + 1][1]); m.visible = false; holder.add(m); });
      model.userData.squadLead = true;
    }
    unitsGroup.add(holder);
    const ring = new THREE.Mesh(new THREE.RingGeometry(STAND_R - .02, STAND_R + .02, 48), new THREE.MeshBasicMaterial({color: 0xffeed0, side: THREE.DoubleSide}));
    ring.rotation.x = -Math.PI / 2; rings.add(ring);
    const label = BADGE[spec.k === 'tank' ? spec.type : spec.k];
    const badge = makeBadge(label, spec.team); if (badge) { badge.visible = false; scene.add(badge); }
    return {spec, holder, model, ring, badge, squad, actors, msz, fw: 1, fl: 1, tbadge: null, phase: idx * 1.7, baseY: 0, baseScale: 1, cell: [...spec.c], yaw: spec.face, path: null, dist: 0, curY: 0, topOff: 1.5, x: spec.c[0] * 2, z: spec.c[1] * 2, tris: triCount(model)};
  });

  const ghostCache = new Map();
  const ghostOf = m => { let g = ghostCache.get(m); if (!g) { g = m.clone(); g.transparent = true; g.opacity = .5; g.depthWrite = false; ghostCache.set(m, g); } return g; };
  // 附楼规则（按建筑类型 × 附件类型）：attach = 驻军时跟着主建筑正面一起后缩（贴着楼不悬空），被单位挡住即可；sym = 左右对称向外挤，两侧位移相同；挤到极限仍压到单位就整对一起消失
  const ACC_RULES = {bld_hq: {steps: 'attach', wall: 'sym'}};
  function applyAccRules(b, fp) {
    const rules = ACC_RULES[b.type]; if (!rules || !fp) return;
    const R = [-fp[0] / 2 - .04, .45 - fp[1] / 2 - .04, fp[0] / 2 + .04, .45 + fp[1] / 2 + .04];   // 与 v1.6 排布一致的单位占地框（朝向系）
    const home = p => { p.position.set(p.userData.home[0], 0, p.userData.home[1]); p.rotation.y = 0; p.visible = true; };
    const rect = p => { const [w, d] = Math.abs(Math.sin(p.rotation.y)) > .5 ? [p.userData.size[1], p.userData.size[0]] : p.userData.size; return [p.position.x - w / 2, p.position.z - d / 2, p.position.x + w / 2, p.position.z + d / 2]; };
    const ov = (a, c) => a[0] < c[2] - .005 && a[2] > c[0] + .005 && a[1] < c[3] - .005 && a[3] > c[1] + .005;
    const fixed = [];
    const dz = measureFront(b.visual) - b.front0;          // 主建筑正面相对空置时的位移（驻军时为负）
    for (const p of b.acc) if (rules[p.userData.type] === 'attach') { home(p); p.position.z += dz; fixed.push(rect(p)); }
    const sym = b.acc.filter(p => rules[p.userData.type] === 'sym');
    if (sym.length) {
      let need = 0, room = Infinity;
      for (const p of sym) {
        home(p);
        const [w, d] = p.userData.size, hx = Math.abs(p.userData.home[0]), hz = p.userData.home[1];
        room = Math.min(room, .99 - (hx + w / 2));                                   // 向外还能挤多远（不出格）
        if (hz + d / 2 > R[1] && hz - d / 2 < R[3]) need = Math.max(need, R[2] - (hx - w / 2));   // 要完全让开单位占地框需要挤多远
      }
      const sft = Math.max(0, Math.min(need, room));
      for (const p of sym) p.position.x += (Math.sign(p.userData.home[0]) || 1) * sft;
      // 兜底：挤到极限仍压到单位占地框时，该对镜像围墙一起消失（左右同时，保持对称）
      const pairs = new Map(); for (const p of sym) { const k = Math.abs(p.userData.home[0]).toFixed(3) + '|' + p.userData.home[1].toFixed(3); (pairs.get(k) || pairs.set(k, []).get(k)).push(p); }
      for (const ps of pairs.values()) { const hit = ps.some(p => ov(rect(p), R)); for (const p of ps) { p.visible = !hit; if (!hit) fixed.push(rect(p)); } }
    }
    for (const p of b.acc) if (!rules[p.userData.type] && p.visible) { const r = rect(p); if (fixed.some(f => ov(r, f))) p.visible = false; }   // 树 / 灌木若压到保留件就隐藏
  }
  function refreshBuildings() {
    for (const b of buildings) {
      const ou = units.find(u => !u.path && u.cell[0] === b.cell[0] && u.cell[1] === b.cell[1]), occ = !!ou;
      setBuildingAccent(b.visual, accentOf(b.owner));
      if (b.visual.userData.transport) {
        if (b.type === 'bld_airport') b.visual.rotation.y = bTheta(b);
        else setDockyardState(b.visual.children[0], {landOccupied: occ});
      } else {
        const th = bTheta(b);
        let fp;
        if (occ && state.annexPush) {   // 单位占地（相对建筑朝向的外接矩形），量化到 0.05 防止每帧重排
          const psi = ou.yaw - th, cp = Math.abs(Math.cos(psi)), sp = Math.abs(Math.sin(psi));
          const q = v => Math.min(2.6, Math.ceil(v / .05) * .05);
          fp = [q(ou.fw * cp + ou.fl * sp), q(ou.fw * sp + ou.fl * cp)];
        }
        const prevKey = b.visual.userData.accessoryLayoutKey;
        setBuildingDisplayState(b.visual, {occupied: occ, viewQuarter: bq(), ...(fp ? {unitFootprint: fp} : {})});
        const grpA = b.visual.getObjectByName('vacant_annexes');
        if (state.annexPush) {
          grpA.visible = true;
          if (b.visual.userData.accessoryLayoutKey !== prevKey) { applyAccRules(b, fp); for (const p of b.acc) { const d = p.userData; d.tgt = [p.position.x, p.position.z]; p.position.set(d.cur[0], 0, d.cur[1]); } }
        } else {   // 不挤开：驻军时整组附楼隐藏，空置时归位
          grpA.visible = !occ;
          for (const p of b.acc) { const d = p.userData; d.cur = [p.userData.home[0], p.userData.home[1]]; d.tgt = [d.cur[0], d.cur[1]]; p.position.set(d.cur[0], 0, d.cur[1]); p.rotation.y = 0; p.visible = true; }
          b.visual.userData.accessoryLayoutKey = undefined;
        }
      }
      const ghost = state.treeMode === 2 && occ;
      b.visual.traverse(o => {
        if (!o.isMesh) return;
        if (o.name === 'accent' || o.name === 'tower_flag_accent') o.userData.orig = o.material; else o.userData.orig = o.userData.orig || o.material;
        o.material = ghost ? ghostOf(o.userData.orig) : o.userData.orig;
      });
    }
  }
  // 步兵测试接口：姿态（idle / aim / kneel）与开火。有选中的步兵就只作用于它，否则作用于全部不在移动中的步兵
  const infTargets = () => { const sel = state.selected; const L = sel && sel.actors ? [sel] : units.filter(u => u.actors); return L.filter(u => !u.path); };
  function setInfPose(name) { state.infPose = name; for (const u of infTargets()) for (const a of u.actors) a.setMode(name); }
  function fireInfantry(shots = 3) {
    for (const u of infTargets()) u.actors.forEach((a, i) => { if (a.mode === 'idle') a.setMode(state.infPose === 'kneel' ? 'kneel' : 'aim'); a.shoot(shots, i * .07); });
  }
  function cycleOwner(cell) { const b = bldMap.get(cell[0] + ',' + cell[1]); if (!b) return null; const real = buildings.find(x => x.cell[0] === b.cell[0] && x.cell[1] === b.cell[1]); real.owner = OWNER_NEXT[real.owner]; refreshBuildings(); return real; }
  function syncUnit(u) {
    const y = u.path ? u.curY : groundY(u.cell[0], u.cell[1]);
    u.holder.position.set(u.x, y, u.z); u.holder.rotation.y = u.yaw;
    u.ring.position.set(u.x, y + .05, u.z);
    if (u.badge) u.badge.position.set(u.x, y + u.topOff + .45, u.z);
    if (state.selected === u) selRing.position.set(u.x, y + .07, u.z);
    syncTerrainBadge(u, y);
  }
  const TLABEL = {forest: '林', mountain: '山', building: '城'}, tbTex = {};
  function terrainBadgeSprite(label) {
    if (typeof document === 'undefined') return null;
    if (!tbTex[label]) {
      const c = document.createElement('canvas'); c.width = c.height = 96; const x = c.getContext('2d');
      x.fillStyle = 'rgba(30,40,46,.88)'; x.strokeStyle = '#ffe9a8'; x.lineWidth = 5; x.beginPath(); x.roundRect(8, 8, 80, 80, 18); x.fill(); x.stroke();
      x.fillStyle = '#ffe9a8'; x.font = 'bold 54px -apple-system,PingFang SC,sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(label, 48, 52);
      const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; tbTex[label] = t;
    }
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({map: tbTex[label], depthTest: false, transparent: true})); sp.scale.set(.42, .42, 1); sp.renderOrder = 19; return sp;
  }
  function syncTerrainBadge(u, y) {
    const label = TLABEL[terrainAt(u.cell[0], u.cell[1])];
    if (!state.terrBadges || !label || !state.units) { if (u.tbadge) u.tbadge.visible = false; return; }
    if (!u.tbadge || u.tbadge.userData.label !== label) { if (u.tbadge) scene.remove(u.tbadge); u.tbadge = terrainBadgeSprite(label); if (!u.tbadge) return; u.tbadge.userData.label = label; scene.add(u.tbadge); }
    const a = state.camA, rx = Math.cos(a), rz = -Math.sin(a), cx = Math.sin(a), cz = Math.cos(a);
    u.tbadge.visible = true; u.tbadge.position.set(u.x + rx * .95 + cx * .35, y + .3, u.z + rz * .95 + cz * .35);
  }
  function applyUnits() {
    for (const u of units) {
      u.baseScale = S * state.unitK * (u.spec.k === 'art' ? state.artK : 1) * (state.sizeMode === 1 ? state.clsK[tkey(u)] : 1);
      const squadOn = state.sizeMode === 2 && u.spec.k === 'inf';
      if (u.squad) u.squad.forEach(m => { m.visible = squadOn; });
      if (u.spec.k === 'inf') u.model.position.set(squadOn ? SQUAD_OFF[0][0] : 0, 0, squadOn ? SQUAD_OFF[0][1] : 0);
      u.fw = squadOn ? 2.3 : u.msz.x * u.baseScale; u.fl = squadOn ? 1.5 : u.msz.z * u.baseScale;
      if (!u.path) { [u.x, u.z] = standPos(u.cell[0], u.cell[1]); }
      u.baseY = u.path ? u.curY : groundY(u.cell[0], u.cell[1]);
      u.holder.scale.setScalar(u.baseScale);
      u.holder.rotation.set(0, u.yaw, 0);
      if (u.spec.k === 'art') u.model.setAim(0, state.artElev); else if (u.spec.k === 'tank') u.model.setAim(0, 0);
      u.holder.position.set(u.x, u.baseY, u.z); u.holder.updateMatrixWorld(true);
      u.topOff = new THREE.Box3().setFromObject(u.holder).max.y - u.baseY;
      syncUnit(u);
      if (u.badge) u.badge.visible = state.badges && state.units;
    }
    unitsGroup.visible = state.units;
    refreshBuildings();
    if (state.selected) showHighlights(state.selected);
  }

  // ───────── 选中 / 移动范围 / 移动 ─────────
  const MOVE = {inf: 3, light: 6, medium: 5, heavy: 4, art: 4};       // 移动力（点数）
  const SPEED = {inf: 3.0, light: 5.0, medium: 4.4, heavy: 3.6, art: 3.8};  // 动画速度（单位/秒）
  const tkey = u => u.spec.k === 'tank' ? u.spec.type : u.spec.k;
  const terrainAt = (cx, cz) => isSea(cx, cz) ? 'sea' : bldMap.has(cx + ',' + cz) ? 'building' : mtnSet.has(cx + ',' + cz) ? 'mountain' : forestHas(cx, cz) ? 'forest' : roadSet.has(cx + ',' + cz) ? 'road' : 'plain';
  const costOf = (tk, cx, cz) => { const t = terrainAt(cx, cz); if (t === 'sea') return Infinity; if (t === 'mountain') return tk === 'inf' ? 2 : Infinity; if (t === 'forest') return tk === 'inf' ? 1 : 2; return 1; };
  const key = (x, z) => x + ',' + z;
  function reachable(u) {
    const tk = tkey(u), pts = MOVE[tk], start = key(...u.cell);
    const dist = new Map([[start, 0]]), prev = new Map(), occ = new Map();
    for (const o of units) if (o !== u) occ.set(key(...o.cell), o);
    const pq = [[0, u.cell[0], u.cell[1]]];
    while (pq.length) {
      pq.sort((a, b) => a[0] - b[0]); const [d, x, z] = pq.shift(); if (d > dist.get(key(x, z))) continue;
      for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, nz = z + dz;
        if (nx < MAP.x[0] || nx > MAP.x[1] || nz < MAP.z[0] || nz > MAP.z[1]) continue;
        const c = costOf(tk, nx, nz); if (!isFinite(c)) continue;
        const o = occ.get(key(nx, nz)); if (o && o.spec.team !== u.spec.team) continue;   // 敌人挡路，友军可穿过
        const nd = d + c, k = key(nx, nz); if (nd > pts) continue;
        if (nd < (dist.get(k) ?? Infinity)) { dist.set(k, nd); prev.set(k, [x, z]); pq.push([nd, nx, nz]); }
      }
    }
    return {dist, prev, occ, start, pts};
  }
  const hl = new THREE.Group(); scene.add(hl);
  const hlGeo = new THREE.PlaneGeometry(1.84, 1.84).rotateX(-Math.PI / 2), hlGeoSmall = new THREE.PlaneGeometry(1.1, 1.1).rotateX(-Math.PI / 2);
  const hlMat = new THREE.MeshBasicMaterial({color: 0x8fe3ff, transparent: true, opacity: .42, depthWrite: false});
  const selRing = new THREE.Mesh(new THREE.RingGeometry(.86, .98, 40).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({color: 0xffe08a, depthWrite: false}));
  selRing.visible = false; scene.add(selRing);
  function clearHighlights() { for (const o of [...hl.children]) hl.remove(o); }
  function showHighlights(u) {
    clearHighlights(); const R = reachable(u); u.reach = R;
    for (const [k, d] of R.dist) {
      if (k === R.start || R.occ.has(k)) continue;
      const [x, z] = k.split(',').map(Number), mtn = terrainAt(x, z) === 'mountain';
      const m = new THREE.Mesh(mtn ? hlGeoSmall : hlGeo, hlMat); m.position.set(x * 2, groundY(x, z) + (mtn ? .06 : .07), z * 2); m.renderOrder = 5; hl.add(m);
    }
    selRing.visible = true; syncUnit(u);
  }
  function select(u) { if (units.some(o => o.path)) return false; state.selected = u; showHighlights(u); return true; }
  function deselect() { state.selected = null; clearHighlights(); selRing.visible = false; }
  function canMoveTo(u, cell) { const R = u.reach || reachable(u), k = key(cell[0], cell[1]); return R.dist.has(k) && k !== R.start && !R.occ.has(k); }
  function pathTo(u, cell) { const R = u.reach || reachable(u); const out = []; let k = key(cell[0], cell[1]); while (k && k !== R.start) { out.push(k.split(',').map(Number)); const p = R.prev.get(k); k = p ? key(p[0], p[1]) : null; } out.push([...u.cell]); return out.reverse(); }
  function moveTo(u, cell) {
    if (!canMoveTo(u, cell)) return false;
    u.path = pathTo(u, cell); u.dist = 0; u.curY = groundY(u.cell[0], u.cell[1]);
    clearHighlights(); refreshBuildings(); return true;
  }
  let treeEasing = false;
  function update(dt, camAngle) {
    let moving = false, info = null;
    for (const u of units) {
      if (!u.path) continue; moving = true;
      let spd = SPEED[tkey(u)];
      if (u.actors) {   // 步兵：跑 = 世界速度不变、按脚步节奏换算播放速率；走 = 速度降到走路步幅的 1.6 倍
        const gait = state.infGait, clip = u.actors[0].clip(gait), sc = u.baseScale;
        spd = gait === 'run' ? SPEED.inf : clip.speed * sc * 1.6;
        const rate = Math.min(3, spd / (clip.speed * sc));
        for (const a of u.actors) { if (a.mode !== gait) a.setMode(gait); a.advance(dt, rate); }
      }
      const total = (u.path.length - 1) * 2; u.dist += spd * dt;
      const d = Math.min(u.dist, total), i = Math.min(Math.floor(d / 2), u.path.length - 2), f = (d - i * 2) / 2;
      const a = u.path[i], b = u.path[i + 1];
      const pt = (c, idx) => (idx === 0 || idx === u.path.length - 1) ? standPos(c[0], c[1]) : [c[0] * 2, c[1] * 2];
      const pa = pt(a, i), pb = pt(b, i + 1);
      u.x = pa[0] + (pb[0] - pa[0]) * f; u.z = pa[1] + (pb[1] - pa[1]) * f;
      const ya = groundY(a[0], a[1]), yb = groundY(b[0], b[1]); u.curY = ya + (yb - ya) * (f * f * (3 - 2 * f));
      let dy = Math.atan2(b[0] - a[0], b[1] - a[1]) - u.yaw; dy = Math.atan2(Math.sin(dy), Math.cos(dy));
      u.yaw += Math.max(-10 * dt, Math.min(10 * dt, dy));
      if (u.dist >= total) {
        u.cell = [...u.path[u.path.length - 1]]; u.path = null; if (u.actors) for (const a of u.actors) a.setMode(state.infPose); [u.x, u.z] = standPos(u.cell[0], u.cell[1]); u.baseY = groundY(u.cell[0], u.cell[1]); refreshBuildings();
        if (state.selected === u) deselect();
      }
      syncUnit(u);
    }
    for (const u of units) if (u.actors) for (const a of u.actors) if (a.update(dt)) moving = true;   // 开火动画
    { const k = 1 - Math.exp(-12 * dt); for (const b of buildings) for (const nd of b.acc) { const d = nd.userData, ex = d.tgt[0] - d.cur[0], ez = d.tgt[1] - d.cur[1]; if (Math.abs(ex) + Math.abs(ez) > .004) { d.cur[0] += ex * k; d.cur[1] += ez * k; moving = true; } else { d.cur[0] = d.tgt[0]; d.cur[1] = d.tgt[1]; } nd.position.set(d.cur[0], 0, d.cur[1]); } }
    if (moving || treeEasing) { info = refreshTrees(camAngle, dt); treeEasing = info.easing; if (treeEasing) moving = true; }
    return {moving, info};
  }
  // 屏幕射线 → 格坐标（山格用站位面高度再求一次）
  const plane0 = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), _hit = new THREE.Vector3();
  function cellFromRay(ray) {
    if (!ray.intersectPlane(plane0, _hit)) return null;
    let cx = Math.round(_hit.x / 2), cz = Math.round(_hit.z / 2);
    const py = new THREE.Plane(new THREE.Vector3(0, 1, 0), -MTN_STAND * state.mtnK);
    if (ray.intersectPlane(py, _hit)) { const mx = Math.round(_hit.x / 2), mz = Math.round(_hit.z / 2); if (terrainAt(mx, mz) === 'mountain') { cx = mx; cz = mz; } }
    return [cx, cz];
  }

  // 待机动画（整单位微动，不改几何）：步兵呼吸/重心/转头，坦克怠速抖动+炮塔缓扫，火炮炮管微摆
  function animate(t) {
    if (!state.idle) return;
    for (const u of units) {
      if (u.path) continue;
      const ph = u.phase, h = u.holder, k = u.spec.k;
      if (k === 'inf') {
        const b = 1 + .008 * Math.sin(t * 2.2 + ph);
        h.scale.set(u.baseScale, u.baseScale * b, u.baseScale);
        h.rotation.z = .012 * Math.sin(t * .9 + ph);
        h.rotation.y = u.yaw + .05 * Math.sin(t * .35 + ph);
        h.position.y = u.baseY;
      } else {
        h.position.y = u.baseY + .006 * (1 + Math.sin(t * 11 + ph)) + .003 * (1 + Math.sin(t * 17 + ph * 2));  // 只向上抖，不陷进地面
        if (k === 'tank') u.model.setAim(9 * Math.sin(t * .45 + ph), 0);
        else u.model.setAim(6 * Math.sin(t * .4 + ph), state.artElev + 1.5 * Math.sin(t * .8 + ph));
      }
    }
  }

  // 单位级视锥剔除 + 网格级视锥剔除开关
  const _f = new THREE.Frustum(), _m = new THREE.Matrix4(), _s = new THREE.Sphere();
  let meshCulling = true;
  function setMeshCulling(flag) {
    if (flag === meshCulling) return; meshCulling = flag;
    scene.traverse(o => { if (o.isMesh) o.frustumCulled = flag; });
  }
  function cull(camera) {
    setMeshCulling(state.cull);
    if (!state.cull) { for (const u of units) u.holder.visible = state.units; return {inView: units.length, total: units.length}; }
    camera.updateMatrixWorld();
    _m.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse); _f.setFromProjectionMatrix(_m);
    let n = 0;
    for (const u of units) {
      _s.center.set(u.holder.position.x, u.holder.position.y + .9, u.holder.position.z); _s.radius = CULL_R;
      const vis = _f.intersectsSphere(_s); u.holder.visible = state.units && vis; if (vis) n++;
    }
    return {inView: n, total: units.length};
  }

  // 树：林间空地（单位脚下让位）+ 前方让位（挡在镜头与单位之间的树缩小）
  const fadeMat = MAT_TERRAIN.clone(); fadeMat.transparent = true; fadeMat.opacity = .3; fadeMat.depthWrite = false;
  function setTreeMat(t, fade) {
    if (t.faded === fade) return; t.faded = fade;
    t.obj.traverse(m => { if (m.isMesh) m.material = fade ? fadeMat : MAT_TERRAIN; });
  }
  function refreshTrees(camAngle, dt = 1) {
    const dx = Math.sin(camAngle), dz = Math.cos(camAngle), mode = state.treeMode;
    let cleared = 0, yielded = 0, faded = 0, moved = 0, easing = false;
    const k = dt >= 1 ? 1 : 1 - Math.exp(-14 * dt);
    for (const t of trees) {
      let st = 0, px = t.x, pz = t.z;   // st: 0 正常  1 隐藏  2 缩小  3 半透明
      if (state.units) for (const u of units) {
        const vx = t.x - u.x, vz = t.z - u.z;
        if (mode === 0) {
          if (Math.hypot(vx, vz) < 1.0) { st = 1; break; }
          if (state.yieldOn) { const along = vx * dx + vz * dz, lat = Math.abs(vx * dz - vz * dx); if (along > .4 && along < 2.7 && lat < 1.0) st = 2; }
          continue;
        }
        const c = Math.cos(u.yaw), s2 = Math.sin(u.yaw), lx = vx * c - vz * s2, lz = vx * s2 + vz * c;
        const hx = u.fw / 2 + TRUNK_R + .06, hz = u.fl / 2 + TRUNK_R + .06;      // 只看树干：树冠可以盖住单位
        if (Math.abs(lx) >= hx || Math.abs(lz) >= hz) continue;
        if (mode === 2) { st = 3; continue; }
        // 挤开：候选 = 推到侧边 / 推到前后端；优先选仍在本格内、位移最小的
        const sx = lx >= 0 ? 1 : -1, sz = lz >= 0 ? 1 : -1;
        const cands = [[sx * hx * 1.02, lz], [lx, sz * hz * 1.02]].map(([a, b]) => {
          const wx = u.x + a * c + b * s2, wz = u.z - a * s2 + b * c;
          return {wx, wz, d: Math.hypot(wx - t.x, wz - t.z), inCell: Math.abs(wx - t.hcx * 2) <= 1.05 && Math.abs(wz - t.hcz * 2) <= 1.05};
        });
        cands.sort((p1, p2) => (p2.inCell - p1.inCell) || (p1.d - p2.d));
        px = cands[0].wx; pz = cands[0].wz; moved++; break;
      }
      t.cx += (px - t.cx) * k; t.cz += (pz - t.cz) * k;
      if (Math.abs(px - t.cx) > .004 || Math.abs(pz - t.cz) > .004) easing = true; else { t.cx = px; t.cz = pz; }
      const o = t.obj; o.position.x = t.cx; o.position.z = t.cz;
      setTreeMat(t, st === 3);
      if (st === 1) { o.visible = false; cleared++; }
      else { o.visible = true; if (st === 2) { o.scale.set(.5, .5 * state.treeK, .5); yielded++; } else { o.scale.set(1, state.treeK, 1); if (st === 3) faded++; } }
    }
    return {cleared, yielded, faded, moved, easing};
  }

  const api = {
    scene, units, trees, state, mountain, get ground() { return ground; }, rings, groundY,
    TREE_LABELS, SIZE_LABELS, cycleOwner, setInfPose, fireInfantry, buildings, bldMap, animate, cull, update, select, deselect, canMoveTo, moveTo, cellFromRay, reachable, tkey, MOVE,
    apply(camAngle) { state.camA = camAngle; state.viewQuarter = (((Math.round((camAngle - .08 * Math.PI) / (Math.PI / 2))) % 4) + 4) % 4; if (state.sandbox !== lastSand || state.mtnK !== lastMtnK || state.floorTint !== lastTint) rebuildBoard(); mountain.scale.y = state.mtnK; applyUnits(); rings.visible = state.rings && state.units; return refreshTrees(camAngle); },
    stats() {
      const visTri = o => { let n = 0; o.traverseVisible(m => { if (m.isMesh) { const g = m.geometry; n += (g.index ? g.index.count : g.attributes.position.count) / 3; } }); return Math.round(n); };
      const t = {buildings: buildings.reduce((n, b) => n + visTri(b.visual), 0), ground: triCount(ground), roads: triCount(roads), mountain: triCount(mountain), trees: trees.reduce((n, x) => n + triCount(x.obj), 0), units: units.reduce((n, u) => n + u.tris, 0)};
      t.total = t.buildings + t.ground + t.roads + t.mountain + t.trees + t.units; return t;
    }
  };
  api.apply(0.08 * Math.PI);
  return api;
}
