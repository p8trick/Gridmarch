// 步兵 V6.7 集成层：一个原型（构造约 0.6 s / 3 MB）→ 每队着色 → 任意多个共享几何的实例。
// 实例只复制关节层级；走 / 跑 / 站 / 瞄准 / 跪射 全部是烘焙帧插值，运行时无 IK。
import * as THREE from 'three';
import {createSoldier as createRig} from './soldier-rig.js';
import {createInfantryFire} from './infantry-fire.js';

const TEAM_TINT = {blue: [.3, .62, 1.55], red: [.95, .45, .5]};   // 与旧版烘焙步兵同一组倍率
// 迷彩 / 卡其色顶点（衣服、头盔、背带）上队色；皮肤、黑色装备、靴子保持原色
const isCamo = (r, g, b) => { const mx = Math.max(r, g, b); return mx >= .15 && r <= g * 1.45 && b <= mx * .62; };

let base = null;
const teamProtos = new Map();
const getBase = () => base || (base = createRig());

function tintedProto(team) {
  let p = teamProtos.get(team); if (p) return p;
  const src = getBase(); p = src.clone(true); p.name = 'Infantry_' + team;
  const k = TEAM_TINT[team] || [1, 1, 1]; let tinted = 0, total = 0;
  p.traverse(o => {
    if (!o.isMesh) return;
    const g0 = o.geometry, c0 = g0.attributes.color, n = c0.count, arr = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const r = c0.getX(i), g = c0.getY(i), b = c0.getZ(i); total++;
      if (isCamo(r, g, b)) { arr[i * 3] = Math.min(1, r * k[0]); arr[i * 3 + 1] = Math.min(1, g * k[1]); arr[i * 3 + 2] = Math.min(1, b * k[2]); tinted++; }
      else { arr[i * 3] = r; arr[i * 3 + 1] = g; arr[i * 3 + 2] = b; }
    }
    const g = new THREE.BufferGeometry();    // 位置 / 法线与原型共享，只有颜色属性是每队一份
    g.setAttribute('position', g0.attributes.position); if (g0.attributes.normal) g.setAttribute('normal', g0.attributes.normal);
    g.setAttribute('color', new THREE.BufferAttribute(arr, 3)); g.boundingSphere = g0.boundingSphere; g.boundingBox = g0.boundingBox;
    o.geometry = g;
  });
  p.userData.tintStats = {tinted, total};
  teamProtos.set(team, p); return p;
}

export const infantryTintStats = team => tintedProto(team).userData.tintStats;

/** 创建一个可动画的步兵。返回 actor：{root, mode, phase, fire, setMode, advance, shoot, update, dispose} */
export function createInfantryActor(team) {
  const b = getBase().bake, root = tintedProto(team).clone(true);
  const byName = {}; root.traverse(o => { if (o.name) byName[o.name] = o; });
  const J = b.order.map(n => byName[n]);
  root.joints = Object.fromEntries(b.order.map((n, i) => [n, J[i]]));
  const apply = (fa, ia, fb, ib, t) => { for (let j = 0; j < J.length; j++) { const g = J[j]; g.position.copy(fa[ia][j].p).lerp(fb[ib][j].p, t); g.quaternion.copy(fa[ia][j].q).slerp(fb[ib][j].q, t); } };
  root.setPose = name => { const f = b.statics[name]; if (!f) throw Error('pose: idle | aim | kneel'); apply([f], 0, [f], 0, 0); root.userData.pose = name; };
  root.sampleCycle = (name, phase) => { const f = b.cycles[name], x = ((phase % 1 + 1) % 1) * 48, i = Math.floor(x); apply(f, i, f, i + 1, x - i); root.userData.pose = name; };
  root.sampleFirePose = (name, recoil = 0) => { const f = b.firePoses[name]; if (!f) throw Error('firing pose: aim | kneel'); const x = Math.min(1, Math.max(0, recoil)) * 16, i = Math.min(15, Math.floor(x)); apply(f, i, f, i + 1, x - i); };
  const fire = createInfantryFire(root); fire.setReadabilityScale(1.35);
  const actor = {
    root, fire, mode: 'idle', phase: 0,
    clip: name => root.userData.cycles[name],      // {duration, speed}（模型单位 / 秒，需乘世界缩放）
    setMode(mode) {
      if (fire.active || fire.hasClip) fire.cancel(); actor._wait = 0;
      actor.mode = mode;
      if (mode === 'walk' || mode === 'run') root.sampleCycle(mode, actor.phase); else root.setPose(mode);
    },
    advance(dt, rate = 1) { if (actor.mode !== 'walk' && actor.mode !== 'run') return; actor.phase = (actor.phase + dt / actor.clip(actor.mode).duration * rate) % 1; root.sampleCycle(actor.mode, actor.phase); },
    shoot(shots = 3, delay = 0) {          // delay：小队成员错开起射，避免整齐划一
      if (actor.mode !== 'aim' && actor.mode !== 'kneel') actor.setMode('aim');
      if (delay > 0) { actor._wait = delay; actor._shots = shots; } else fire.start({pose: actor.mode, shots});
    },
    update(dt) {                           // 返回 true 表示本帧还在动，需要重绘
      if (actor._wait > 0) { actor._wait -= dt; if (actor._wait <= 0) fire.start({pose: actor.mode, shots: actor._shots}); return true; }
      if (fire.active) { fire.update(dt); return true; }
      return false;
    },
  };
  root.setPose('idle'); return actor;
}
