import {createTank as createLightTank} from './light-tank-v1_4.js';
import {createTank as createMediumTank} from './medium-tank-v2_2.js';
import {createTank as createHeavyTank} from './heavy-tank-v1_1.js';

export {createLightTank, createMediumTank, createHeavyTank};
export const tankFactories = Object.freeze({light:createLightTank, medium:createMediumTank, heavy:createHeavyTank});
export const tankVersions = Object.freeze({light:'1.4', medium:'2.2', heavy:'1.1'});

export function createTank(type, options={}) {
  const factory=tankFactories[type];
  if(!factory) throw new RangeError(`Unknown tank type: ${type}`);
  return factory(options);
}

export function setAimRadians(model, yawRad=0, elevationRad=0) {
  model.setAim(yawRad*180/Math.PI, elevationRad*180/Math.PI);
}
