import {summaryOf} from '../rules/engine.js';

// 胜利结算面板（0.91，方案 A「双盒战报」+ C 的「看战场」收成底部细横幅）：
// 左盒 = 胜利牌（胜方颜色条 + 盖章「胜利」+ 第 N 天 + 怎么赢的 + 三个按钮），右盒 = 蓝红对照表（条形 = 数量对比，更占优的一边数字放大）。
// 「看战场」= 面板收起，底部留一条细横幅（胜方 · 第 N 天 · 击毁 / 损失 / 据点），点一下重新展开。数据来自规则引擎的统计表（engine.summaryOf），战场情报以后共用。
import {OWN, t} from '../i18n/index.js';
const HOW = {hq: 'res.how.hq', wipe: 'res.how.wipe', draw: 'res.how.draw'};   // 词条键，显示时 t()
const ROWS = [   // better：'hi' 越大越占优、'lo' 越小越占优、null 只比条形不加粗
  ['built', 'res.row.built', null], ['lost', 'res.row.lost', 'lo'], ['killed', 'res.row.killed', 'hi'], ['props', 'res.row.props', 'hi'], ['income', 'res.row.income', 'hi'], ['spent', 'res.row.spent', null],
];
const fmt = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

export function createResult({host, game, onAgain, onHome, onShown}) {
  let el = null, tag = null;
  const build = () => {
    const s = summaryOf(game), w = s.winner, draw = w < 0, cls = draw ? 'army-n' : w === 1 ? 'army-r' : 'army-b';
    el = document.createElement('div'); el.className = 'res ' + cls;
    const col = side => `<span class="res-side ${side ? 'r' : 'b'}${w === side ? ' win' : ''}"><i class="dot ${side ? 'r' : 'b'}"></i>${OWN[side]}${w === side ? `<em>${t('res.winMark')}</em>` : ''}</span>`;
    const rows = ROWS.map(([k, name, better]) => {
      const a = s.sides[0][k], b = s.sides[1][k], mx = Math.max(a, b, 1), cell = (v, o, side) => {
        const lead = better && v !== o && (better === 'hi' ? v > o : v < o);
        return `<div class="res-c ${side ? 'r' : 'b'}${lead ? ' lead' : ''}"><i style="width:${Math.round(v / mx * 100)}%"></i><b>${fmt(v)}</b></div>`;
      };
      return `<div class="res-r">${cell(a, b, 0)}<span class="res-l">${t(name)}</span>${cell(b, a, 1)}</div>`;
    }).join('');
    el.innerHTML = `<div class="res-dim"></div><div class="res-row">
      <div class="res-box res-win">
        <div class="res-ribbon">${t(draw ? 'res.draw' : 'banner.win')}</div>
        <div class="res-team">${draw ? t('banner.allDead') : `<i class="dot ${w ? 'r' : 'b'}"></i>${OWN[w]}`}</div>
        <div class="res-day">${t('hud.day', {n: s.day})}</div>
        <div class="res-how">${HOW[s.reason] ? t(HOW[s.reason]) : ''}</div>
        <div class="res-btns"><button class="res-btn main" data-act="again">${t('res.again')}</button><button class="res-btn" data-act="home">${t('res.home')}</button><button class="res-btn" data-act="view">${t('res.view')}</button></div>
      </div>
      <div class="res-box res-tbl"><div class="res-th">${col(0)}<span class="res-ttl">${t('res.report')}</span>${col(1)}</div><div class="res-rows">${rows}</div></div>
    </div>`;
    tag = document.createElement('button'); tag.className = 'res-tag ' + cls; tag.hidden = true;
    const k = s.sides, me = draw ? null : k[w];
    tag.innerHTML = draw ? `<b>${t('res.draw')}</b><span>${t('hud.day', {n: s.day})}</span><em>▴</em>` : `<i class="dot ${w ? 'r' : 'b'}"></i><b>${t('res.teamWin', {team: OWN[w]})}</b><span>${t('hud.day', {n: s.day})}</span><span class="k">${t('res.tag.killed', {n: me.killed})}</span><span class="k">${t('res.tag.lost', {n: me.lost})}</span><span class="k">${t('res.tag.props', {n: me.props})}</span><em>▴</em>`;
    host.appendChild(el); host.appendChild(tag);
    el.addEventListener('click', e => {
      const b = e.target.closest('.res-btn'); if (!b) return;
      const a = b.dataset.act;
      if (a === 'again') onAgain(); else if (a === 'home') onHome(); else if (a === 'view') min(true);
    });
    tag.addEventListener('click', () => min(false));
  };
  function min(on) { if (!el) return; el.hidden = on; tag.hidden = !on; host.classList.toggle('res-open', !on); if (!on) { el.classList.remove('in'); void el.offsetWidth; el.classList.add('in'); } if (onShown) onShown(on); }
  function open() { if (el) return; build(); el.classList.add('in'); host.classList.add('res-open'); }
  function dispose() { if (el) { el.remove(); tag.remove(); el = tag = null; } host.classList.remove('res-open'); }
  return {open, dispose, get isOpen() { return !!el && !el.hidden; }, get minimized() { return !!el && el.hidden; }, get exists() { return !!el; }};
}
